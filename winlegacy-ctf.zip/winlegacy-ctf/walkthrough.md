# WinLegacy CTF - Official Solution Walkthrough

This is the step-by-step guide to completely pwning the WinLegacy 3.1 retro environment!

## Phase 1: Bypassing the Lock Screen
When you first load the page, you are greeted with a retro 4-color Windows logo bouncing around the screen.
1. Click the bouncing logo **7 times**.
2. The lock screen will disappear, granting you access to the WinLegacy desktop environment.

## Phase 2: Reconnaissance
Once on the desktop, you have four applications available.
1. Open the **README.txt** app. 
2. It reveals crucial information about the system architecture:
   > - Remind admin to secure the internal port 8080. It should not be accessible from the public network setup.
   > - Terminal access requires a valid session token.
3. Open the **File Manager**. Click through the files until you open `manifesto.txt`. 
4. At the bottom of the manifesto, you'll find the exact internal API path that the admins forgot to hide:
   > ADMIN REMINDER: The legacy token generation service at `/api/legacy/token` must be isolated...

## Phase 3: Exploiting SSRF (Server-Side Request Forgery)
We know there is an internal service running on `port 8080` at the path `/api/legacy/token`. We can't access port 8080 from the outside, but we can make the server fetch it for us!
1. Open the **Network Setup** app on the desktop.
2. In the "Server URL" input field, type the full internal URL:
   ```text
   http://127.0.0.1:8080/api/legacy/token
   ```
3. Click **Synchronize Now**.
4. The server will make a request to its own internal port and return the data to you. You will receive a successful sync containing your Auth Token:
   ```json
   {
     "auth_token": "WL-772-99-B"
   }
   ```

## Phase 4: Authenticating the Terminal
Now that you have the internal token, you can unlock the terminal.
1. Open the **MS-DOS Prompt** from the desktop.
2. Type the authentication command using the token you just acquired:
   ```text
   auth WL-772-99-B
   ```
3. Press **Enter**. The terminal will respond with: `AUTHENTICATION SUCCESSFUL. ELEVATED PRIVILEGES GRANTED.`

## Phase 5: Command Injection & Capturing the Flag
The terminal endpoint (`/api/v1/terminal/execute`) is vulnerable to Command Injection because the backend simply executes `echo [your input]` directly in the system shell!

However, the flag has been hidden deep within a realistic fake DOS filesystem! The terminal is now fully **stateful**, so you can navigate around just like a real retro environment.

1. **Find the Flag:** You start at `C:\>`. If you inject `; ls`, you will see realistic folders like `DOS`, `PROGRAMS`, and `WINDOWS`. 
   You can either use command injection to hunt it down using Linux commands:
   ```text
   ; find /C_DRIVE -name "*flag*" 2>/dev/null
   ```
   *Or* you can simply navigate manually using the new stateful commands!
   ```text
   cd WINDOWS
   cd SYSTEM
   ; ls
   ```
2. **Capture the Flag:** Once you locate the file, inject a command to read it:
   ```text
   ; cat hidden_flag_9921.txt
   ```
3. Press **Enter**. The terminal will print out your prize:
   ```text
   flag{w1nl3gacy_c0mmand_1nj3ct10n_m4st3r}
   ```

> [!TIP]
> **Why it works:** The backend code does `exec("echo " + command, { cwd: resolvedPath })`. We built a completely stateful wrapper around it that tracks your directory so `cd WINDOWS` actually changes your environment. By prefixing your input with a semicolon `;`, Linux executes the echo command (which does nothing), and then immediately executes your injected payload inside that directory!
