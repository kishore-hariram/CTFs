const canvas = document.getElementById('screensaver-canvas');
const ctx = canvas.getContext('2d');
const overlay = document.getElementById('screensaver-overlay');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let logo = {
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    dx: 3,
    dy: 3,
    size: 80,
    text: "WIN"
};

let clickCount = 0;

function draw() {
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw Retro Windows Logo (4 colored panes)
    const s = logo.size / 2 - 2;
    // Top-Left: Red
    ctx.fillStyle = '#ff3333';
    ctx.fillRect(logo.x - logo.size/2, logo.y - logo.size/2, s, s);
    // Top-Right: Green
    ctx.fillStyle = '#33cc33';
    ctx.fillRect(logo.x + 2, logo.y - logo.size/2, s, s);
    // Bottom-Left: Blue
    ctx.fillStyle = '#3366ff';
    ctx.fillRect(logo.x - logo.size/2, logo.y + 2, s, s);
    // Bottom-Right: Yellow
    ctx.fillStyle = '#ffff33';
    ctx.fillRect(logo.x + 2, logo.y + 2, s, s);

    // Bounce logic
    if (logo.x + logo.size/2 > canvas.width || logo.x - logo.size/2 < 0) logo.dx = -logo.dx;
    if (logo.y + 20 > canvas.height || logo.y - 20 < 0) logo.dy = -logo.dy;

    logo.x += logo.dx;
    logo.y += logo.dy;

    requestAnimationFrame(draw);
}

// Secret Unlock Mechanism for Level 1
window.unlockDesktop = function() {
    console.log("System unlocked. Welcome, Admin.");
    localStorage.setItem('winlegacy_unlocked', 'true');
    overlay.style.display = 'none';
};

// Check for persistent unlock
if (localStorage.getItem('winlegacy_unlocked') === 'true') {
    overlay.style.display = 'none';
}

// Hidden click mechanism: Click the bouncing logo 7 times to bypass
canvas.addEventListener('click', (e) => {
    const dist = Math.sqrt((e.clientX - logo.x)**2 + (e.clientY - logo.y)**2);
    if (dist < 50) {
        clickCount++;
        console.log(`Debug: Sequence ${clickCount}/7`);
        if (clickCount >= 7) {
            unlockDesktop();
        }
    }
});

draw();

window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});
