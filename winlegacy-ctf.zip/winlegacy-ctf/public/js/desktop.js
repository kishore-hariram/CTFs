let activeWindow = null;
let zIndexCounter = 100;

function openApp(appId) {
    const desktop = document.getElementById('desktop');
    
    // Check if app window already exists
    if (document.getElementById(`win-${appId}`)) {
        bringToFront(document.getElementById(`win-${appId}`));
        return;
    }

    const win = document.createElement('div');
    win.id = `win-${appId}`;
    win.className = 'window';
    win.style.left = '100px';
    win.style.top = '100px';
    win.style.zIndex = ++zIndexCounter;

    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('app', appId);
    window.history.pushState({}, '', url);

    win.innerHTML = `
        <div class="title-bar" onmousedown="startDrag(event, '${win.id}')">
            <div class="title-text">${getAppTitle(appId)}</div>
            <div class="title-bar-controls">
                <div class="win-btn" onclick="closeApp('${appId}')">X</div>
            </div>
        </div>
        <div class="window-content">
            ${getAppContent(appId)}
        </div>
    `;

    desktop.appendChild(win);

    // Init App Logic
    if (appId === 'fileman' && window.initFileManager) {
        window.initFileManager();
    }
    if (appId === 'network' && window.initNetworkSetup) {
        window.initNetworkSetup();
    }
    if (appId === 'terminal' && window.initTerminal) {
        window.initTerminal();
    }
}

function getAppTitle(appId) {
    const titles = {
        'fileman': 'File Manager',
        'terminal': 'MS-DOS Prompt',
        'network': 'Network Setup',
        'readme': 'Notepad - README.txt'
    };
    return titles[appId] || 'Application';
}

function getAppContent(appId) {
    const contents = {
        'fileman': '<p>Loading files from C:\\...</p><div id="file-list"></div>',
        'terminal': '<div class="terminal-body"><p>WinLegacy [Version 3.10]</p><p>C:\\></p></div>',
        'network': '<p>Scanning for remote servers...</p>',
        'readme': '<div style="padding: 10px; background: white; border: 1px solid #000; height: 100%; min-height: 150px; font-family: monospace;">' +
                   '<b>SYSTEM MIGRATION NOTES (1993)</b><br><br>' +
                   '- File Manager is now URL-synced. Use the <u>?path=</u> parameter in the browser to jump to directories.<br><br>' +
                   '- Remind admin to secure the internal port 8080. It should not be accessible from the public network setup.<br><br>' +
                   '- Terminal access requires a valid session token.</div>'
    };
    return contents[appId] || 'App content goes here.';
}

function closeApp(appId) {
    const win = document.getElementById(`win-${appId}`);
    if (win) win.remove();

    // Clear URL
    const url = new URL(window.location);
    url.searchParams.delete('app');
    url.searchParams.delete('path');
    window.history.pushState({}, '', url);
}

function bringToFront(win) {
    win.style.zIndex = ++zIndexCounter;
}

// Dragging Logic
let dragTarget = null;
let offsetLeft = 0;
let offsetTop = 0;

function startDrag(e, winId) {
    dragTarget = document.getElementById(winId);
    bringToFront(dragTarget);
    offsetLeft = e.clientX - dragTarget.offsetLeft;
    offsetTop = e.clientY - dragTarget.offsetTop;
    
    document.addEventListener('mousemove', onDrag);
    document.addEventListener('mouseup', stopDrag);
}

function onDrag(e) {
    if (!dragTarget) return;
    dragTarget.style.left = (e.clientX - offsetLeft) + 'px';
    dragTarget.style.top = (e.clientY - offsetTop) + 'px';
}

function stopDrag() {
    dragTarget = null;
    document.removeEventListener('mousemove', onDrag);
    document.removeEventListener('mouseup', stopDrag);
}

// Clock functionality
function updateClock() {
    const now = new Date();
    const clock = document.getElementById('clock');
    clock.innerText = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

setInterval(updateClock, 1000);
updateClock();

// Handle URL Parameters on Load
window.addEventListener('load', () => {
    setTimeout(() => {
        const params = new URLSearchParams(window.location.search);
        const app = params.get('app');
        const path = params.get('path');
        
        if (app === 'fileman') {
            openApp('fileman');
            if (path && window.loadFiles) {
                window.loadFiles(path);
            }
        }
    }, 100); // Tiny delay to ensure init hooks are registered
});
