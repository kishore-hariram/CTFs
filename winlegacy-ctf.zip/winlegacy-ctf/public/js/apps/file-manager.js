async function loadFiles(dir = '.') {
    const fileList = document.getElementById('file-list');
    if (!fileList) return;

    // Sync with URL for LFI visibility
    const url = new URL(window.location);
    url.searchParams.set('app', 'fileman');
    url.searchParams.set('path', dir);
    window.history.pushState({}, '', url);

    fileList.innerHTML = '<p>Loading...</p>';

    try {
        const response = await fetch(`/api/v1/files?dir=${encodeURIComponent(dir)}`);
        const data = await response.json();

        if (data.status === 'ok') {
            fileList.innerHTML = `
                <div class="file-nav">
                    <button onclick="loadFiles('${getParentDir(dir)}')">Up</button>
                    <input type="text" id="path-input" value="${data.currentDir}" style="flex: 1; margin: 0 5px;">
                    <button onclick="loadFiles(document.getElementById('path-input').value)">Go</button>
                </div>
                <ul class="file-ul">
                    ${data.files.map(file => `
                        <li class="file-item ${file.isDirectory ? 'dir' : 'file'}" 
                            onclick="${file.isDirectory ? `loadFiles('${dir === '.' ? file.name : dir + '/' + file.name}')` : `viewFile('${dir}', '${file.name}')`}">
                            ${file.isDirectory ? '📁' : '📄'} ${file.name}
                        </li>
                    `).join('')}
                </ul>
            `;
        } else {
            fileList.innerHTML = `<p class="error">Error: ${data.message}</p>`;
        }
    } catch (err) {
        fileList.innerHTML = `<p class="error">Error: ${err.message}</p>`;
    }
}

function getParentDir(dir) {
    if (dir === '.') return '.';
    const parts = dir.split('/');
    parts.pop();
    return parts.length === 0 ? '.' : parts.join('/');
}

async function viewFile(dir, name) {
    const fullPath = dir === '.' ? name : dir + '/' + name;
    const fileList = document.getElementById('file-list');
    
    fileList.innerHTML = '<p>Reading file...</p>';
    
    try {
        // We use the same API but the server needs to handle file reading
        const response = await fetch(`/api/v1/files/read?path=${encodeURIComponent(fullPath)}`);
        const data = await response.json();
        
        if (data.status === 'ok') {
            fileList.innerHTML = `
                <div class="file-nav">
                    <button onclick="loadFiles('${dir}')">Back</button>
                    <span>Viewing: ${name}</span>
                </div>
                <pre class="file-content">${data.content}</pre>
            `;
        } else {
            fileList.innerHTML = `<p class="error">Error: ${data.message}</p><button onclick="loadFiles('${dir}')">Back</button>`;
        }
    } catch (err) {
        fileList.innerHTML = `<p class="error">Error: ${err.message}</p><button onclick="loadFiles('${dir}')">Back</button>`;
    }
}

// Global hook for app initialization
window.initFileManager = () => {
    loadFiles('.');
};
