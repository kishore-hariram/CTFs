async function handleTerminalInput(e) {
    if (e.key === 'Enter') {
        const input = e.target.value;
        const output = document.getElementById('terminal-output');
        
        const currentCwd = window.currentTerminalCwd || 'C:\\';
        // Append command to output
        output.innerHTML += `<div>${currentCwd}> ${input}</div>`;
        e.target.value = '';

        try {
            const response = await fetch('/api/v1/terminal/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ command: input, cwd: currentCwd })
            });
            const data = await response.json();

            if (data.status === 'ok') {
                if (data.output) output.innerHTML += `<div class="term-res">${data.output}</div>`;
            } else {
                output.innerHTML += `<div class="term-err">Error: ${data.message}</div>`;
            }
            
            if (data.newCwd) {
                window.currentTerminalCwd = data.newCwd;
                document.getElementById('term-prompt').innerHTML = `${data.newCwd}>&nbsp;`;
            }
        } catch (err) {
            output.innerHTML += `<div class="term-err">System Error: ${err.message}</div>`;
        }
        
        // Auto-scroll
        const body = document.querySelector('.terminal-body');
        body.scrollTop = body.scrollHeight;
    }
}

window.initTerminal = () => {
    const content = document.querySelector('#win-terminal .window-content');
    if (content) {
        content.innerHTML = `
            <div class="terminal-body" style="background: #000; color: #ccc; font-family: 'Courier New', Courier, monospace; font-size: 14px; font-weight: bold; height: 300px; overflow-y: auto; padding: 10px; margin: -10px;">
                <div id="terminal-output">
                    <div>WinLegacy [Version 3.10]</div>
                    <div>(c) Copyright 1985-1993 Heritage Systems Corp.</div>
                    <br>
                </div>
                <div style="display: flex;">
                    <span id="term-prompt">C:\\>&nbsp;</span>
                    <input type="text" id="term-input" style="background: transparent; border: none; color: #fff; outline: none; flex: 1; font-family: inherit; font-size: inherit; font-weight: inherit;" spellcheck="false" autocomplete="off" autofocus>
                </div>
            </div>
        `;
        const input = document.getElementById('term-input');
        input.addEventListener('keydown', handleTerminalInput);
        input.focus();
    }
};
