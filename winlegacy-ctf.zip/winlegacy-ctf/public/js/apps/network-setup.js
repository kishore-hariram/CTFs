async function syncNetwork() {
    const urlInput = document.getElementById('server-url');
    const statusDiv = document.getElementById('sync-status');
    
    if (!urlInput || !statusDiv) return;

    statusDiv.innerHTML = '<p>Synchronizing...</p>';

    try {
        const response = await fetch('/api/v1/network/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ server_url: urlInput.value })
        });
        const data = await response.json();

        if (data.status === 'ok') {
            statusDiv.innerHTML = `
                <p class="success">Sync Successful!</p>
                <div class="sync-data">
                    <pre>${JSON.stringify(data.data, null, 2)}</pre>
                </div>
            `;
        } else {
            statusDiv.innerHTML = `<p class="error">Sync Failed: ${data.message}</p>`;
        }
    } catch (err) {
        statusDiv.innerHTML = `<p class="error">Error: ${err.message}</p>`;
    }
}

window.initNetworkSetup = () => {
    const content = document.querySelector('#win-network .window-content');
    if (content) {
        content.innerHTML = `
            <div class="network-setup">
                <p>Enter the Remote Archive Server URL to synchronize records:</p>
                <div class="field">
                    <label>Server URL:</label>
                    <input type="text" id="server-url" value="http://archive.legacy.org/api/v1" style="width: 200px;">
                </div>
                <button onclick="syncNetwork()" style="margin-top: 10px;">Synchronize Now</button>
                <div id="sync-status" style="margin-top: 15px;"></div>
            </div>
        `;
    }
};
