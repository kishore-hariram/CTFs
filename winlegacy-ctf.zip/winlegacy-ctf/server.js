const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

// API Endpoints for Challenges
app.get('/api/v1/files', (req, res) => {
    const baseDir = path.join(__dirname, 'data', 'public');
    const targetDir = req.query.dir ? path.join(baseDir, req.query.dir) : baseDir;
    
    const fs = require('fs');
    try {
        if (!fs.existsSync(targetDir)) {
            return res.status(404).json({ status: 'error', message: 'Directory not found' });
        }
        
        const files = fs.readdirSync(targetDir).map(file => {
            const stats = fs.statSync(path.join(targetDir, file));
            return {
                name: file,
                isDirectory: stats.isDirectory(),
                size: stats.size
            };
        });
        res.json({ status: 'ok', currentDir: req.query.dir || '.', files });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
});

app.get('/api/v1/files/read', (req, res) => {
    const baseDir = path.join(__dirname, 'data', 'public');
    const targetFile = req.query.path ? path.join(baseDir, req.query.path) : null;
    
    if (!targetFile) {
        return res.status(400).json({ status: 'error', message: 'Missing path' });
    }

    const fs = require('fs');
    try {
        if (!fs.existsSync(targetFile) || fs.statSync(targetFile).isDirectory()) {
            return res.status(404).json({ status: 'error', message: 'File not found' });
        }
        
        const content = fs.readFileSync(targetFile, 'utf8');
        res.json({ status: 'ok', content });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
});

app.post('/api/v1/network/sync', async (req, res) => {
    const { server_url } = req.body;
    
    if (!server_url) {
        return res.status(400).json({ status: 'error', message: 'Missing server_url' });
    }

    try {
        const axios = require('axios');
        // SSRF Vulnerability: We fetch whatever the user provides
        const response = await axios.get(server_url, { timeout: 2000 });
        res.json({ status: 'ok', data: response.data });
    } catch (err) {
        res.status(500).json({ status: 'error', message: `Sync failed: ${err.message}` });
    }
});

// Simulated Internal Service (Hidden from outside)
const internalApp = express();
internalApp.get('/api/legacy/token', (req, res) => {
    res.json({
        system: 'WinLegacy Internal Management',
        status: 'Online',
        auth_token: 'WL-772-99-B',
        note: 'Terminal access granted for this token. Use: auth <token>'
    });
});
internalApp.listen(8080, '127.0.0.1', () => {
    console.log('Internal management service running on port 8080');
});

// Simple in-memory session for the terminal auth
let isTerminalAuthenticated = false;

app.post('/api/v1/terminal/execute', (req, res) => {
    const { command, cwd } = req.body;
    
    if (!command) {
        return res.status(400).json({ status: 'error', message: 'Missing command' });
    }

    const parts = command.trim().split(' ');
    const cmd = parts[0].toLowerCase();

    let fakeCwd = cwd || 'C:\\';
    let realCwd = fakeCwd.replace(/^C:\\?/i, '/C_DRIVE/').replace(/\\/g, '/');
    if (!realCwd.startsWith('/C_DRIVE')) realCwd = '/C_DRIVE';

    // Layer 4 Auth Logic
    if (cmd === 'auth') {
        const token = parts[1];
        if (token === 'WL-772-99-B') {
            isTerminalAuthenticated = true;
            return res.json({ status: 'ok', output: 'AUTHENTICATION SUCCESSFUL. ELEVATED PRIVILEGES GRANTED.' });
        } else {
            return res.json({ status: 'ok', output: 'INVALID TOKEN.' });
        }
    }

    if (!isTerminalAuthenticated) {
        return res.json({ status: 'ok', output: 'ACCESS DENIED. PLEASE AUTHENTICATE.', newCwd: fakeCwd });
    }

    if (cmd === 'cd') {
        const target = parts[1] || '';
        if (target === '..') {
            realCwd = path.join(realCwd, '..');
            if (!realCwd.startsWith('/C_DRIVE')) realCwd = '/C_DRIVE';
        } else if (target === '\\\\' || target === '/') {
            realCwd = '/C_DRIVE';
        } else {
            realCwd = path.join(realCwd, target);
            if (!realCwd.startsWith('/C_DRIVE')) realCwd = '/C_DRIVE';
        }
        
        let newFakeCwd = realCwd.replace(/^\/C_DRIVE/, 'C:').split('/').join('\\\\');
        if (newFakeCwd === 'C:') newFakeCwd = 'C:\\\\';
        
        return res.json({ status: 'ok', output: '', newCwd: newFakeCwd });
    }

    const { exec } = require('child_process');
    // Command Injection Vulnerability
    const fullCommand = `echo ${command}`;
    
    exec(fullCommand, { cwd: realCwd }, (error, stdout, stderr) => {
        if (error) {
            return res.status(500).json({ status: 'error', message: stderr || error.message, newCwd: fakeCwd });
        }
        res.json({ status: 'ok', output: stdout, newCwd: fakeCwd });
    });
});

app.listen(port, () => {
    console.log(`WinLegacy 3.1 running at http://localhost:${port}`);
});
