export const Router = {
  routes: {},
  currentScreen: null,
  
  register(hashPattern, screenFactory) {
    this.routes[hashPattern] = screenFactory;
  },
  
  navigate(hash) {
    window.location.hash = hash;
  },
  
  init() {

    this.boundHandleRoute = this.handleRoute.bind(this);
    window.addEventListener('hashchange', this.boundHandleRoute);
    this.handleRoute();
  },
  
  handleRoute() {
    let hash = window.location.hash || '#';
    if (!hash.startsWith('#')) {
      hash = '#' + hash;
    }
    
    let matchedPattern = null;
    let params = {};

    for (const pattern of Object.keys(this.routes)) {

      const regexPattern = pattern.replace(/:[^\s/]+/g, '([^/]+)');
      const regex = new RegExp(`^${regexPattern}$`);
      const match = hash.match(regex);
      
      if (match) {
        matchedPattern = pattern;

        const paramNames = (pattern.match(/:[^\s/]+/g) || []).map(p => p.substring(1));
        paramNames.forEach((name, index) => {
          params[name] = match[index + 1];
        });
        break;
      }
    }
    
    if (matchedPattern) {
      if (this.currentScreen && this.currentScreen.destroy) {
        this.currentScreen.destroy();
      }
      
      const factory = this.routes[matchedPattern];
      this.currentScreen = factory(params);
    } else {
      console.warn('No route matched for hash, falling back to boot:', hash);
      window.location.hash = '#';
    }
  },
  
  getCurrentRoute() {
    return window.location.hash;
  },
  
  destroy() {
    if (this.boundHandleRoute) {
      window.removeEventListener('hashchange', this.boundHandleRoute);
    }
    if (this.currentScreen && this.currentScreen.destroy) {
      this.currentScreen.destroy();
      this.currentScreen = null;
    }
  }
};
