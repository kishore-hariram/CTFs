const STATE_KEY = 'phantom_shell_state';

const defaultState = {
  player: {
    name: null,
    totalScore: 0,
    startTime: null,
  },
  challenges: {},
};

let currentState = null;
const listeners = new Set();

function saveState() {
  localStorage.setItem(STATE_KEY, JSON.stringify(currentState));
  listeners.forEach(cb => cb(currentState));
}

export const GameState = {
  init() {
    try {
      const stored = localStorage.getItem(STATE_KEY);
      if (stored) {
        currentState = JSON.parse(stored);
      } else {
        currentState = JSON.parse(JSON.stringify(defaultState));
        saveState();
      }
    } catch (e) {
      console.error('Failed to load state', e);
      currentState = JSON.parse(JSON.stringify(defaultState));
    }
  },
  
  getPlayer() {
    return currentState.player;
  },
  
  setPlayer(name) {
    currentState.player.name = name;
    if (!currentState.player.startTime) {
      currentState.player.startTime = Date.now();
    }
    saveState();
  },
  
  getChallengeState(id) {
    if (!currentState.challenges[id]) {
      currentState.challenges[id] = { solved: false, score: 0, hintsUsed: 0, solvedAt: null };
      saveState();
    }
    return currentState.challenges[id];
  },
  
  solveChallenge(id, score) {
    const state = this.getChallengeState(id);
    if (!state.solved) {
      state.solved = true;
      state.score = score;
      state.solvedAt = Date.now();
      currentState.player.totalScore += score;
      saveState();
    }
  },
  
  useHint(id) {
    const state = this.getChallengeState(id);
    state.hintsUsed += 1;
    saveState();
  },
  
  getAllProgress() {
    return currentState.challenges;
  },
  
  getScore() {
    return currentState.player.totalScore;
  },
  
  getSolvedCount() {
    return Object.values(currentState.challenges).filter(c => c.solved).length;
  },
  
  reset() {
    currentState = JSON.parse(JSON.stringify(defaultState));
    saveState();
  },
  
  onStateChange(callback) {
    listeners.add(callback);
    return () => listeners.delete(callback);
  }
};
