export class TerminalEngine {
  constructor(container, options = {}) {
    this.container = container;
    this.options = {
      prompt: '$ ',
      user: 'ghost',
      host: 'phantom',
      cwd: '~',
      onCommand: async () => {},
      ...options
    };
    
    this.history = [];
    this.historyIndex = -1;
    this.isInputEnabled = true;
    
    this.buildUI();
  }
  
  buildUI() {
    this.container.innerHTML = '';
    this.container.classList.add('terminal-container');

    this.container.style.fontFamily = '"VT323", "Share Tech Mono", monospace';
    this.container.style.backgroundColor = '#0a0a0a';
    this.container.style.color = '#00ff41';
    this.container.style.padding = '10px';
    this.container.style.height = '100%';
    this.container.style.overflowY = 'auto';
    this.container.style.boxSizing = 'border-box';
    this.container.style.display = 'flex';
    this.container.style.flexDirection = 'column';

    this.outputElement = document.createElement('div');
    this.outputElement.className = 'terminal-output';
    this.outputElement.style.flex = '1 1 auto';
    
    this.inputLine = document.createElement('div');
    this.inputLine.className = 'terminal-input-line';
    this.inputLine.style.display = 'flex';
    this.inputLine.style.alignItems = 'center';
    
    this.promptElement = document.createElement('span');
    this.promptElement.className = 'terminal-prompt';
    this.promptElement.style.marginRight = '8px';
    this.promptElement.style.whiteSpace = 'pre';
    this.updatePromptUI();
    
    this.inputElement = document.createElement('input');
    this.inputElement.type = 'text';
    this.inputElement.className = 'terminal-input';
    this.inputElement.style.flex = '1';
    this.inputElement.style.backgroundColor = 'transparent';
    this.inputElement.style.border = 'none';
    this.inputElement.style.color = 'inherit';
    this.inputElement.style.fontFamily = 'inherit';
    this.inputElement.style.fontSize = 'inherit';
    this.inputElement.style.outline = 'none';
    this.inputElement.style.caretColor = '#00ff41';
    
    this.inputLine.appendChild(this.promptElement);
    this.inputLine.appendChild(this.inputElement);
    
    this.container.appendChild(this.outputElement);
    this.container.appendChild(this.inputLine);
    
    this.inputElement.addEventListener('keydown', this.handleKeyDown.bind(this));
    this.container.addEventListener('click', () => this.focus());
  }
  
  updatePromptUI() {

    const displayPath = this.options.cwd === '/home/' + this.options.user ? '~' : this.options.cwd || '~';
    this.promptElement.textContent = `${this.options.user}@${this.options.host}:${displayPath}${this.options.prompt}`;
  }
  
  async handleKeyDown(e) {
    if (!this.isInputEnabled) {
      e.preventDefault();
      return;
    }
    
    if (e.key === 'Enter') {
      const val = this.inputElement.value;
      this.inputElement.value = '';
      this.writeLine(this.promptElement.textContent + val);
      
      if (val.trim()) {
        this.history.push(val);
        this.historyIndex = this.history.length;
      }
      
      await this.execute(val);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (this.historyIndex > 0) {
        this.historyIndex--;
        this.inputElement.value = this.history[this.historyIndex];
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (this.historyIndex < this.history.length - 1) {
        this.historyIndex++;
        this.inputElement.value = this.history[this.historyIndex];
      } else {
        this.historyIndex = this.history.length;
        this.inputElement.value = '';
      }
    }
  }
  
  async execute(rawInput) {
    const trimmed = rawInput.trim();
    if (!trimmed) return;

    const parts = trimmed.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
    if (parts.length === 0) return;
    
    const command = parts[0];
    const args = parts.slice(1).map(p => {
      if ((p.startsWith('"') && p.endsWith('"')) || (p.startsWith("'") && p.endsWith("'"))) {
        return p.slice(1, -1);
      }
      return p;
    });
    
    if (command === 'clear') {
      this.clear();
      return;
    }
    
    if (command === 'help') {
      this.writeLine('Available commands: clear, help');

    }
    
    this.disable();
    try {
      await this.options.onCommand(command, args, this);
    } catch (err) {
      this.writeError(`Error: ${err.message}`);
    }
    this.enable();
    this.updatePromptUI();
    this.focus();
  }
  
  writeLine(text, className = '') {
    const line = document.createElement('div');
    line.textContent = text;
    if (className) line.className = className;
    line.style.whiteSpace = 'pre-wrap';
    line.style.wordBreak = 'break-all';
    this.outputElement.appendChild(line);
    this.scrollToBottom();
  }
  
  writeLines(lines) {
    lines.forEach(l => this.writeLine(l));
  }
  
  writeHTML(html) {
    const line = document.createElement('div');
    line.innerHTML = html;
    this.outputElement.appendChild(line);
    this.scrollToBottom();
  }
  
  writeError(text) {
    const line = document.createElement('div');
    line.textContent = text;
    line.style.color = '#ff4444';
    line.style.whiteSpace = 'pre-wrap';
    this.outputElement.appendChild(line);
    this.scrollToBottom();
  }
  
  writeSuccess(text) {
    const line = document.createElement('div');
    line.textContent = text;
    line.style.color = '#33ff66';
    line.style.whiteSpace = 'pre-wrap';
    this.outputElement.appendChild(line);
    this.scrollToBottom();
  }
  
  writeTable(headers, rows) {

    let colWidths = headers.map(h => h.length);
    rows.forEach(row => {
      row.forEach((cell, i) => {
        const len = cell ? cell.toString().length : 0;
        if (len > colWidths[i]) {
          colWidths[i] = len;
        }
      });
    });
    
    const separator = '+' + colWidths.map(w => '-'.repeat(w + 2)).join('+') + '+';
    
    const formatRow = (rowData) => {
      return '|' + rowData.map((d, i) => ' ' + (d || '').toString().padEnd(colWidths[i]) + ' ').join('|') + '|';
    };
    
    this.writeLine(separator);
    this.writeLine(formatRow(headers));
    this.writeLine(separator);
    rows.forEach(row => this.writeLine(formatRow(row)));
    this.writeLine(separator);
  }
  
  clear() {
    this.outputElement.innerHTML = '';
  }
  
  setPrompt(prompt) {
    this.options.prompt = prompt;
    this.updatePromptUI();
  }
  
  setUser(user, host) {
    this.options.user = user;
    this.options.host = host;
    this.updatePromptUI();
  }
  
  disable() {
    this.isInputEnabled = false;
    this.inputElement.disabled = true;
    this.inputElement.style.opacity = '0.5';
  }
  
  enable() {
    this.isInputEnabled = true;
    this.inputElement.disabled = false;
    this.inputElement.style.opacity = '1';
  }
  
  focus() {
    if (this.isInputEnabled) {
      this.inputElement.focus();
    }
  }
  
  scrollToBottom() {
    this.container.scrollTop = this.container.scrollHeight;
  }
  
  async typeWrite(text, speed = 30) {
    const line = document.createElement('div');
    line.style.whiteSpace = 'pre-wrap';
    line.style.wordBreak = 'break-all';
    this.outputElement.appendChild(line);
    
    for (let i = 0; i < text.length; i++) {
      line.textContent += text.charAt(i);
      this.scrollToBottom();
      await new Promise(r => setTimeout(r, speed));
    }
  }
  
  destroy() {
    this.container.innerHTML = '';
  }
}
