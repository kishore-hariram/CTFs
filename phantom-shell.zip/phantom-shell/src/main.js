import { initCRTOverlay } from './components/crtOverlay.js';
import { Router } from './engine/router.js';
import { GameState } from './engine/gameState.js';
import { SoundEngine } from './components/soundEngine.js';
import { renderBootScreen, destroyBootScreen } from './screens/bootScreen.js';
import { renderGameScreen, destroyGameScreen } from './screens/gameScreen.js';

async function bootstrap() {
  const app = document.getElementById('app');

  initCRTOverlay();
  SoundEngine.init();
  GameState.init();

  Router.register('#', (params) => {
    renderBootScreen(app);
    return { destroy: destroyBootScreen };
  });

  Router.register('#game', (params) => {
    renderGameScreen(app);
    return { destroy: destroyGameScreen };
  });

  Router.init();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootstrap);
} else {
  bootstrap();
}
