import { TerminalEngine } from '../engine/terminalEngine.js';
import { GameState } from '../engine/gameState.js';
import { SoundEngine } from '../components/soundEngine.js';

const FLAG = atob('RkxBR3swcDNyNHQxMG5fbTR0cnkwc2hrNF9jMG1wbDN0M30=');

let containerElement = null;
let terminal = null;

const fileSystem = {

  '/': { type: 'dir', contents: ['home', 'var', 'etc', 'usr'] },
  '/home': { type: 'dir', contents: ['guest', 'analyst', 'admin'] },
  '/home/guest': { type: 'dir', contents: ['readme.txt'] },
  '/home/guest/readme.txt': { type: 'file', content: atob('V2VsY29tZSB0byBQaGFudG9tT1MuIFlvdXIgYWNjZXNzIGlzIHJlc3RyaWN0ZWQuCklmIHlvdSBhcmUgc3RhZmYsIHBsZWFzZSBzd2l0Y2ggdG8geW91ciBhY2NvdW50IHVzaW5nIHRoZSAic3UiIGNvbW1hbmQuClVzYWdlOiBzdSA8dXNlcm5hbWU+IDxwYXNzd29yZD4=') },

  '/home/analyst': { type: 'dir', contents: ['tasks.txt'], locked: 'analyst' },
  '/home/analyst/tasks.txt': { type: 'file', content: atob('MS4gUmV2aWV3IGxhdGVzdCBwYWNrZXQgY2FwdHVyZXMgaW4gL3Zhci9sb2cvcGFja2V0cy5sb2cKMi4gSWRlbnRpZnkgdGhlIGV4ZmlsdHJhdGlvbiBwb3J0CjMuIFRoZSBhZG1pbiBwYXNzd29yZCBpcyB0aGUgYW5vbWFsb3VzIHBvcnQgbnVtYmVyIGZvbGxvd2VkIGJ5ICJfYWRtaW4iIChlLmcuIDgwODBfYWRtaW4p') },
  '/var': { type: 'dir', contents: ['log', 'tmp'] },
  '/var/tmp': { type: 'dir', contents: ['.hidden_config'] },
  '/var/tmp/.hidden_config': { type: 'dir', contents: ['credentials.bak'] },
  '/var/tmp/.hidden_config/credentials.bak': { type: 'file', content: atob('YW5hbHlzdDogaDRja3RoM3BsNG4zdAphZG1pbjogW0VOQ1JZUFRFRF0=') },
  '/var/log': { type: 'dir', contents: ['packets.log', 'syslog'] },
  '/var/log/packets.log': { type: 'file', content: atob('WzIwMjQtMDUtMTIgMTQ6MDBdIFNSQz0xOTIuMTY4LjEuNSBEU1Q9MTAuMC4wLjEgUE9SVD04MApbMjAyNC0wNS0xMiAxNDowMV0gU1JDPTE5Mi4xNjguMS42IERTVD0xMC4wLjAuMSBQT1JUPTQ0MwpbMjAyNC0wNS0xMiAxNDowNV0gU1JDPTEwLjAuMC45OSBEU1Q9MTkyLjE2OC4xLjEwIFBPUlQ9MzEzMzcKWzIwMjQtMDUtMTIgMTQ6MTBdIFNSQz0xOTIuMTY4LjEuNyBEU1Q9MTAuMC4wLjEgUE9SVD04MA==') },
  '/var/log/syslog': { type: 'file', content: atob('U3lzdGVtIHN0YXJ0ZWQgbm9ybWFsbHku') },

  '/home/admin': { type: 'dir', contents: ['notes.txt'], locked: 'admin' },
  '/home/admin/notes.txt': { type: 'file', content: atob('RG8gbm90IGZvcmdldCB0byBwYXRjaCB0aGUgcGhhbnRvbS1yZWFkZXIgYmluYXJ5IGluIC91c3IvbG9jYWwvYmluLiBJdCBpcyBzdGlsbCBydW5uaW5nIGFzIFNVSUQgcm9vdC4=') },
  '/usr': { type: 'dir', contents: ['local'] },
  '/usr/local': { type: 'dir', contents: ['bin', 'share'] },
  '/usr/local/bin': { type: 'dir', contents: ['phantom-reader'] },
  '/usr/local/bin/phantom-reader': { type: 'file', content: atob('f0VMRi4uLiBbYmluYXJ5IGRhdGFd'), perms: '-rwsr-xr-x root' },
  '/usr/local/share': { type: 'dir', contents: ['docs'] },
  '/usr/local/share/docs': { type: 'dir', contents: ['manual.txt'] },
  '/usr/local/share/docs/manual.txt': { type: 'file', content: atob('VXNhZ2U6IHBoYW50b20tcmVhZGVyIDxmaWxlbmFtZT4gLSByZWFkcyBmaWxlcyBmcm9tIHRoZSBkb2NzIGRpcmVjdG9yeQ==') },

  '/root': { type: 'dir', contents: ['flag.txt'], locked: 'root' },
  '/root/flag.txt': { type: 'file', content: FLAG },
  
  '/etc': { type: 'dir', contents: ['passwd'] },
  '/etc/passwd': { type: 'file', content: atob('cm9vdDp4OjA6MDpyb290Oi9yb290Oi9iaW4vYmFzaApndWVzdDp4OjEwMDA6MTAwMDpHdWVzdDovaG9tZS9ndWVzdDovYmluL2Jhc2gKYW5hbHlzdDp4OjEwMDE6MTAwMTpBbmFseXN0Oi9ob21lL2FuYWx5c3Q6L2Jpbi9iYXNoCmFkbWluOng6MTAwMjoxMDAyOkFkbWluOi9ob21lL2FkbWluOi9iaW4vYmFzaA==') }
};

export function renderGameScreen(container) {
  containerElement = container;
  container.innerHTML = '';
  
  const wrapper = document.createElement('div');
  wrapper.style.width = '100%';
  wrapper.style.height = '100%';
  wrapper.style.display = 'flex';
  wrapper.style.flexDirection = 'column';

  const header = document.createElement('div');
  header.className = 'status-bar';
  const player = GameState.getPlayer() || { name: 'Unknown' };
  header.innerHTML = `
    <div>AGENT: <span style="color:#fff">${player.name}</span></div>
    <div>MISSION: Operation Matryoshka</div>
    <div id="layer-status" style="color: #ff3333">ACCESS: GUEST</div>
  `;
  wrapper.appendChild(header);

  const terminalContainer = document.createElement('div');
  terminalContainer.style.flex = '1';
  terminalContainer.style.position = 'relative';
  wrapper.appendChild(terminalContainer);
  
  container.appendChild(wrapper);

  terminal = new TerminalEngine(terminalContainer, {
    prompt: 'guest@phantom:~$ ',
    user: 'guest',
    host: 'phantom',
    cwd: '/home/guest',
    onCommand: async (cmd, args, term) => {
      let currentPath = term.options.cwd;

      const resolvePath = (p, base = currentPath) => {
        if (!p) return base;
        if (p.startsWith('/')) return p.replace(/\/+$/, '') || '/';
        let parts = base === '/' ? [] : base.split('/').filter(Boolean);
        p.split('/').forEach(part => {
          if (part === '..') parts.pop();
          else if (part !== '.' && part !== '') parts.push(part);
        });
        return '/' + parts.join('/');
      };

      const getDir = (p) => {
        let r = resolvePath(p, currentPath);
        if (r === '') r = '/';
        return fileSystem[r];
      };

      const canAccess = (node) => {
        if (!node.locked) return true;
        let user = term.options.user;
        if (user === 'root') return true;
        if (node.locked === 'root' && user !== 'root') return false;
        if (node.locked === 'admin' && user !== 'root' && user !== 'admin') return false;
        if (node.locked === 'analyst' && user !== 'root' && user !== 'admin' && user !== 'analyst') return false;
        return true;
      };

      const updateHeaderStatus = (user) => {
          const statusEl = document.getElementById('layer-status');
          if (statusEl) {
              if (user === 'guest') { statusEl.style.color = '#ff3333'; statusEl.textContent = 'ACCESS: GUEST'; }
              if (user === 'analyst') { statusEl.style.color = '#ffeb3b'; statusEl.textContent = 'ACCESS: ANALYST'; }
              if (user === 'admin') { statusEl.style.color = '#33ff66'; statusEl.textContent = 'ACCESS: ADMIN'; }
          }
      };

      switch (cmd) {
        case 'ls': {
          let showAll = args.includes('-a') || args.includes('-la') || args.includes('-al');
          let target = args.filter(a => !a.startsWith('-'))[0] || '.';
          let dirPath = resolvePath(target);
          let dir = getDir(dirPath);
          
          if (!dir) {
            term.writeError(`ls: cannot access '${target}': No such file or directory`);
          } else if (!canAccess(dir)) {
            term.writeError(`ls: cannot open directory '${target}': Permission denied`);
          } else if (dir.type === 'file') {
            term.writeLine(target);
          } else {
            let contents = dir.contents.filter(item => {
              let itemPath = dirPath === '/' ? `/${item}` : `${dirPath}/${item}`;
              let isHidden = fileSystem[itemPath]?.hidden || item.startsWith('.');
              return showAll ? true : !isHidden;
            });
            if (showAll) {
              contents = ['.', '..', ...contents];
            }
            term.writeLine(contents.join('  '));
          }
          break;
        }
        case 'cd': {
          let target = args[0] || `/home/${term.options.user}`;
          let dirPath = resolvePath(target);
          let dir = getDir(dirPath);
          
          if (!dir) {
            term.writeError(`cd: ${target}: No such file or directory`);
          } else if (dir.type !== 'dir') {
            term.writeError(`cd: ${target}: Not a directory`);
          } else if (!canAccess(dir)) {
            term.writeError(`cd: ${target}: Permission denied`);
          } else {
            term.options.cwd = dirPath;
            let displayPath = dirPath === `/home/${term.options.user}` ? '~' : dirPath;
            term.setPrompt(`${term.options.user}@phantom:${displayPath}$ `);
          }
          break;
        }
        case 'cat': {
          if (args.length === 0) {
            term.writeError('cat: missing operand');
            break;
          }
          let target = args[0];
          let filePath = resolvePath(target);
          let file = getDir(filePath);
          
          if (!file) {
            term.writeError(`cat: ${target}: No such file or directory`);
          } else if (file.type === 'dir') {
            term.writeError(`cat: ${target}: Is a directory`);
          } else if (!canAccess(file) || (filePath.startsWith('/root') && term.options.user !== 'root')) {
            term.writeError(`cat: ${target}: Permission denied`);
          } else {
            term.writeLine(file.content);
          }
          break;
        }
        case 'pwd': {
          term.writeLine(currentPath);
          break;
        }
        case 'grep': {
             if (args.length < 2) {
                 term.writeError('grep: missing operand');
                 break;
             }
             let pattern = args[0];
             let target = args[1];
             let filePath = resolvePath(target);
             let file = getDir(filePath);

             if (!file) {
                 term.writeError(`grep: ${target}: No such file or directory`);
             } else if (file.type === 'dir') {
                 term.writeError(`grep: ${target}: Is a directory`);
             } else if (!canAccess(file)) {
                 term.writeError(`grep: ${target}: Permission denied`);
             } else {
                 let lines = file.content.split('\n');
                 lines.forEach(line => {
                     if (line.includes(pattern)) term.writeLine(line);
                 });
             }
             break;
        }
        case 'whoami': {
          term.writeLine(term.options.user);
          break;
        }
        case 'su': {
          let targetUser = args[0];
          let password = args[1];
          if (!targetUser || !password) {
            term.writeError('Usage: su <user> <password>');
            break;
          }
          
          if (targetUser === 'analyst' && btoa(password) === 'aDRja3RoM3BsNG4zdA==') {
            term.options.user = 'analyst';
            term.options.cwd = '/home/analyst';
            term.setPrompt('analyst@phantom:~$ ');
            term.writeSuccess('Switching user to analyst... ACCESS GRANTED');
            updateHeaderStatus('analyst');
          } else if (targetUser === 'admin' && btoa(password) === 'MzEzMzdfYWRtaW4=') {
            term.options.user = 'admin';
            term.options.cwd = '/home/admin';
            term.setPrompt('admin@phantom:~$ ');
            term.writeSuccess('Switching user to admin... ACCESS GRANTED');
            updateHeaderStatus('admin');
          } else {
            term.writeError('su: Authentication failure');
          }
          break;
        }
        case 'phantom-reader': {
            if (args.length === 0) {
                term.writeLine('Usage: phantom-reader <filename>');
                break;
            }
            let target = args[0];

            let baseDir = '/usr/local/share/docs';
            let resolvedFile = resolvePath(target, baseDir);
            
            let file = fileSystem[resolvedFile];
            if(!file) {
                term.writeError(`Error: file '${target}' not found in docs directory.`);
            } else if (file.type === 'dir') {
                term.writeError(`Error: '${target}' is a directory.`);
            } else {
                term.writeLine(file.content);

                if (resolvedFile === '/root/flag.txt') {
                   setTimeout(() => triggerWinState(), 1500);
                }
            }
            break;
        }
        case 'help': {
          term.writeLines([
            'Available commands:',
            'ls [path]             List directory contents',
            'cd <path>             Change working directory',
            'pwd                   Print working directory',
            'cat <file>            Concatenate files',
            'grep <pattern> <file> Print lines matching a pattern',
            'su <user> <password>  Switch user account',
            'whoami                Print effective userid',
            'help                  Display this help message'
          ]);
          break;
        }
        default: {
          if (cmd) {
              if (cmd === '/usr/local/bin/phantom-reader' || (cmd === './phantom-reader' && currentPath === '/usr/local/bin')) {
                  term.writeError('Execute it simply by typing: phantom-reader <filename>');
              } else {
                  term.writeError(`Command not found: ${cmd}`);
              }
          }
        }
      }
    }
  });

  setTimeout(() => {
      terminal.writeLines([
          'PhantomOS v1.0.4 (tty1)',
          '',
          'Welcome to the main server. Your goal is to retrieve the root flag.',
          'Type "help" for a list of available commands.',
          ''
      ]);
      terminal.focus();
  }, 100);
}

function triggerWinState() {
    SoundEngine.playSuccess();
    if (containerElement) {
        containerElement.innerHTML = `
          <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; text-align: center; color: #33ff66; background: #0a0a0a;">
            <h1 class="glow" style="font-size: 3rem; margin-bottom: 20px;">OPERATION MATRYOSHKA COMPLETE</h1>
            <p style="font-size: 1.5rem; color: #fff;">You have successfully escalated to root and acquired the final flag!</p>
            <div style="margin: 40px; padding: 20px; border: 2px dashed #00ff41; font-size: 2rem; background: #003b00; width: 80%; max-width: 600px; word-break: break-all;" class="glow">
              ${FLAG}
            </div>
            <p style="margin-top: 20px; color: #00cc33;">Target compromised. Mission accomplished.</p>
            <button onclick="window.location.reload()" style="margin-top: 40px; background: #003b00; color: #00ff41; border: 1px solid #00ff41; padding: 10px 20px; cursor: pointer; font-family: inherit; font-size: 1.2rem;">REBOOT SYSTEM</button>
          </div>
        `;
    }
}

export function destroyGameScreen() {
  if (terminal) {
    terminal = null;
  }
  if (containerElement) {
    containerElement.innerHTML = '';
  }
}
