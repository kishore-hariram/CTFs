import { typeWriteLines } from '../components/typewriter.js';
import { ASCII_ART, renderASCII } from '../components/asciiArt.js';
import { GameState } from '../engine/gameState.js';
import { SoundEngine } from '../components/soundEngine.js';
import { Router } from '../engine/router.js';

let containerElement = null;
let boundKeyHandler = null;

export async function renderBootScreen(container) {
  containerElement = container;
  container.innerHTML = '';
  container.classList.add('power-on');

  SoundEngine.playBoot();

  const player = GameState.getPlayer();
  if (player && player.name) {
    await renderWelcomeBack(player.name);
    return;
  }

  const postContainer = document.createElement('div');
  postContainer.className = 'boot-post';
  container.appendChild(postContainer);

  const postLines = [
    "PHANTOM SHELL BIOS v3.7.1",
    "Copyright (C) 1987 Phantom Systems Inc.",
    "",
    "Memory Test: 640K OK",
    "Detecting drives... [OK]",
    "Initializing network adapter... [OK]",
    "Loading PHANTOM SHELL OS...",
    "",
    "████████████████████████ 100%",
    "",
    "System ready."
  ];

  await typeWriteLines(postContainer, postLines, 10, 50);

  setTimeout(async () => {
    postContainer.innerHTML = '';

    const logoContainer = document.createElement('div');
    logoContainer.className = 'boot-logo';
    container.appendChild(logoContainer);
    renderASCII(logoContainer, 'LOGO_LARGE', 'glow');

    const promptContainer = document.createElement('div');
    promptContainer.className = 'boot-prompt';
    promptContainer.innerHTML = '<br/>> Enter your callsign to begin: <span class="input-display"></span><span class="cursor blink">█</span>';
    container.appendChild(promptContainer);

    const inputDisplay = promptContainer.querySelector('.input-display');
    let callsign = '';

    boundKeyHandler = async (e) => {
      if (e.key === 'Enter' && callsign.trim().length > 0) {
        document.removeEventListener('keydown', boundKeyHandler);
        boundKeyHandler = null;
        SoundEngine.playSuccess();

        const accessGranted = document.createElement('div');
        accessGranted.className = 'access-granted glow';
        accessGranted.style.fontSize = '1.5rem';
        accessGranted.style.marginTop = '1rem';
        accessGranted.textContent = 'ACCESS GRANTED';
        promptContainer.appendChild(accessGranted);

        const overlay = document.getElementById('crt-overlay');
        if (overlay) {
          overlay.style.backgroundColor = 'rgba(0, 255, 65, 0.15)';
          setTimeout(() => {
            overlay.style.backgroundColor = 'transparent';
          }, 200);
        }

        GameState.setPlayer(callsign.trim());

        setTimeout(() => {
          Router.navigate('#game');
        }, 1500);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        callsign = callsign.slice(0, -1);
        inputDisplay.textContent = callsign;
        SoundEngine.playKeypress();
      } else if (e.key.length === 1 && /[a-zA-Z0-9_\-]/.test(e.key) && callsign.length < 20) {
        callsign += e.key;
        inputDisplay.textContent = callsign;
        SoundEngine.playKeypress();
      }
    };

    document.addEventListener('keydown', boundKeyHandler);
  }, 500);
}

async function renderWelcomeBack(name) {
  const welcome = document.createElement('div');
  welcome.className = 'boot-welcome';
  welcome.style.padding = '2rem';
  containerElement.appendChild(welcome);

  const logoContainer = document.createElement('div');
  logoContainer.className = 'boot-logo';
  containerElement.insertBefore(logoContainer, welcome);
  renderASCII(logoContainer, 'LOGO_LARGE', 'glow');

  await typeWriteLines(welcome, [
    `Welcome back, ${name}.`,
    "Restoring session...",
    "ACCESS GRANTED"
  ], 30, 300);

  SoundEngine.playSuccess();
  setTimeout(() => {
    Router.navigate('#game');
  }, 1000);
}

export function destroyBootScreen() {
  if (boundKeyHandler) {
    document.removeEventListener('keydown', boundKeyHandler);
    boundKeyHandler = null;
  }
  if (containerElement) {
    containerElement.classList.remove('power-on');
    containerElement.innerHTML = '';
  }
}
