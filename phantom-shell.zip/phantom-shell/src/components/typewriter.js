import { SoundEngine } from './soundEngine.js';

export function typeWrite(element, text, speed = 30) {
  return new Promise((resolve) => {
    element.innerHTML = '<span class="typed-text"></span><span class="cursor">_</span>';
    const textSpan = element.querySelector('.typed-text');
    
    let i = 0;
    
    function typeChar() {
      if (i < text.length) {
        if (text.charAt(i) === '\n') {
          textSpan.innerHTML += '<br>';
        } else {
          textSpan.innerHTML += text.charAt(i);
        }

        if (i % 3 === 0 && text.charAt(i) !== ' ' && text.charAt(i) !== '\n') {
          SoundEngine.playType();
        }
        
        i++;
        setTimeout(typeChar, speed + (Math.random() * speed));
      } else {
        resolve();
      }
    }
    
    typeChar();
  });
}

export async function typeWriteLines(element, lines, speed = 30, lineDelay = 200) {
  element.innerHTML = '';
  
  for (let i = 0; i < lines.length; i++) {
    const lineDiv = document.createElement('div');
    element.appendChild(lineDiv);
    
    await typeWrite(lineDiv, lines[i], speed);

    const cursor = lineDiv.querySelector('.cursor');
    if (cursor) cursor.remove();
    
    if (i < lines.length - 1) {
      await new Promise(r => setTimeout(r, lineDelay));
    }
  }

  const lastLine = element.lastElementChild;
  if (lastLine && !lastLine.querySelector('.cursor')) {
    lastLine.innerHTML += '<span class="cursor">_</span>';
  }
}
