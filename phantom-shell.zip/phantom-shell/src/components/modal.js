import { SoundEngine } from './soundEngine.js';

let modalContainer = null;

export function showModal({ title, message, confirmText = 'OK', cancelText = null, onConfirm, onCancel }) {
  if (modalContainer) {
    hideModal();
  }
  
  modalContainer = document.createElement('div');
  modalContainer.className = 'retro-modal-overlay';
  
  const modalBox = document.createElement('div');
  modalBox.className = 'retro-modal-box';
  
  const titleDiv = document.createElement('div');
  titleDiv.className = 'modal-title';
  titleDiv.textContent = `[ ${title} ]`;
  modalBox.appendChild(titleDiv);
  
  const messageDiv = document.createElement('div');
  messageDiv.className = 'modal-message';
  messageDiv.innerHTML = message;
  modalBox.appendChild(messageDiv);
  
  const actionsDiv = document.createElement('div');
  actionsDiv.className = 'modal-actions';
  
  if (cancelText) {
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn-retro btn-cancel';
    cancelBtn.textContent = cancelText;
    cancelBtn.onclick = () => {
      SoundEngine.playKeypress();
      hideModal();
      if (onCancel) onCancel();
    };
    actionsDiv.appendChild(cancelBtn);
  }
  
  const confirmBtn = document.createElement('button');
  confirmBtn.className = 'btn-retro btn-confirm';
  confirmBtn.textContent = confirmText;
  confirmBtn.onclick = () => {
    SoundEngine.playKeypress();
    hideModal();
    if (onConfirm) onConfirm();
  };
  actionsDiv.appendChild(confirmBtn);
  
  modalBox.appendChild(actionsDiv);
  modalContainer.appendChild(modalBox);
  
  document.body.appendChild(modalContainer);

  setTimeout(() => confirmBtn.focus(), 10);
}

export function hideModal() {
  if (modalContainer && modalContainer.parentNode) {
    modalContainer.parentNode.removeChild(modalContainer);
  }
  modalContainer = null;
}
