export function initCRTOverlay() {
  let overlay = document.getElementById('crt-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'crt-overlay';
    document.body.appendChild(overlay);
  }
  
  overlay.classList.add('scanlines');
  overlay.classList.add('flicker');

  Object.assign(overlay.style, {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    pointerEvents: 'none',
    zIndex: 9999,
    background: 'linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06))',
    backgroundSize: '100% 4px, 6px 100%',
    boxShadow: 'inset 0 0 100px rgba(0,0,0,0.9)',
    opacity: 0.8
  });
}

export function toggleCRT(enabled) {
  const overlay = document.getElementById('crt-overlay');
  if (overlay) {
    overlay.style.display = enabled ? 'block' : 'none';
  }
}
