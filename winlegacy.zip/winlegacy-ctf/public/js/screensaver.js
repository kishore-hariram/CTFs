const canvas = document.getElementById('screensaver-canvas');
const ctx = canvas.getContext('2d');
const overlay = document.getElementById('screensaver-overlay');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let logo = {
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    dx: 3,
    dy: 3,
    size: 80,
    text: "WIN"
};

let clickCount = 0;

function draw() {
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);


    const s = logo.size / 2 - 2;

    ctx.fillStyle = '#ff3333';
    ctx.fillRect(logo.x - logo.size/2, logo.y - logo.size/2, s, s);

    ctx.fillStyle = '#33cc33';
    ctx.fillRect(logo.x + 2, logo.y - logo.size/2, s, s);

    ctx.fillStyle = '#3366ff';
    ctx.fillRect(logo.x - logo.size/2, logo.y + 2, s, s);

    ctx.fillStyle = '#ffff33';
    ctx.fillRect(logo.x + 2, logo.y + 2, s, s);


    if (logo.x + logo.size/2 > canvas.width || logo.x - logo.size/2 < 0) logo.dx = -logo.dx;
    if (logo.y + 20 > canvas.height || logo.y - 20 < 0) logo.dy = -logo.dy;

    logo.x += logo.dx;
    logo.y += logo.dy;

    requestAnimationFrame(draw);
}


window.unlockDesktop = function() {

    localStorage.setItem('winlegacy_unlocked', 'true');
    overlay.style.display = 'none';
};


if (localStorage.getItem('winlegacy_unlocked') === 'true') {
    overlay.style.display = 'none';
}


canvas.addEventListener('click', (e) => {
    const dist = Math.sqrt((e.clientX - logo.x)**2 + (e.clientY - logo.y)**2);
    if (dist < 50) {
        clickCount++;

        if (clickCount >= 7) {
            unlockDesktop();
        }
    }
});

draw();

window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});
