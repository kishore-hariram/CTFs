const express = require('express');
const cookieParser = require('cookie-parser');
const app = express();
const port = 5000;

app.use(cookieParser());

const flag = "Flag{I_know_you_come_here}";

app.get('/reset', (req, res) => {
    res.clearCookie('step');
    res.redirect('/');
});

app.get('*', (req, res) => {
    if (req.path === '/favicon.ico') {
        return res.status(404).send();
    }

    let step = parseInt(req.cookies.step) || 0;

    if (step >= flag.length) {
        step = 0;
    }

    const nextChar = flag[step];
    const nextStep = step + 1;

    console.log(`Step ${step}: Redirecting to /${nextChar}`);

    res.cookie('step', nextStep.toString(), { path: '/', httpOnly: true });
    res.redirect('/' + encodeURIComponent(nextChar));
});

app.listen(port, () => {
    console.log(`Vortex CTF challenge running at http://localhost:${port}`);
    console.log(`Flag: ${flag}`);
    console.log(`Point your browser to http://localhost:${port}/ to start the loop.`);
});
