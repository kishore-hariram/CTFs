# LuckyWin Giveaway — CTF Challenge

A CTF web challenge built with **Node.js + Express** themed as a giveaway/prize microsite.

## Vulnerabilities

| Step | Vulnerability | How |
|------|--------------|-----|
| 1 | Information Disclosure | `robots.txt` → `/api/` |
| 2 | API Debug Leak | `GET /api/v1/health` leaks admin credentials in `debug` block |
| 3 | Local File Inclusion (LFI) | `GET /admin/pdf-serve?file=` has no path traversal protection |
| 4 | Mass Assignment | `POST /user/spin` blindly merges request body — add `role: "verified_sponsor"` |

## Challenge Flow

```
1. robots.txt → /api/ discovered
2. GET /api/v1/health → admin:Adm1n@G1v3away! leaked
3. Login as admin → Document Vault (PDF viewer)
4. LFI: GET /admin/pdf-serve?file=../internal/docs/ → directory listing
5. GET /admin/pdf-serve?file=../internal/docs/Q1_2026_budget_review.pdf → read PDF
6. PDF reveals dev note: POST /user/spin with role="verified_sponsor"
7. Login as player:player123 → Spin Wheel
8. POST /user/spin {"spin":true,"role":"verified_sponsor"} → FLAG
```

## Flag

```
FLAG{you_spun_the_wheel_of_fortune}
```

## Setup & Run

```bash
npm install
npm start
```

Server runs on **http://localhost:3000**

PDFs are auto-generated on first startup (requires `pdfkit`).

## Credentials

| Role | Username | Password | Notes |
|------|----------|----------|-------|
| Participant | `player` | `player123` | Shown on landing page |
| Admin | `admin` | `Adm1n@G1v3away!` | Leaked via API |

## Project Structure

```
├── server.js              # Express entry point
├── generate-pdfs.js       # Auto-generates all PDF files on startup
├── routes/
│   ├── auth.js            # Login / logout (rate-limited, no SQLi surface)
│   ├── admin.js           # Admin panel + vulnerable LFI PDF viewer
│   ├── user.js            # User panel + vulnerable spin endpoint
│   └── api.js             # API routes (health endpoint leaks creds)
├── views/
│   ├── landing.ejs        # Landing page with dual login modals
│   ├── admin/             # Admin dashboard, users, stats, PDF vault
│   └── user/              # Dashboard, prizes, referral, profile, spin
├── public/
│   ├── robots.txt         # Hints at /api/ path
│   ├── css/style.css      # Full giveaway microsite styling
│   └── js/spin.js         # Canvas spin wheel animation
├── uploads/               # Fake PDFs (red herrings) — generated on startup
└── internal/docs/         # Real PDF with flag hint — generated on startup
```

## Notes for Challenge Organisers

- Change credentials in `routes/auth.js` before deploying
- The flag is in `routes/user.js` — update `FLAG{...}` as needed
- Fake PDFs each contain a different red-herring role name to mislead participants
- No SQL injection, brute force, or username enumeration vectors exist by design
