/* ── Spin Wheel Canvas Logic ─────────────────────────── */

const SECTORS = [
  { label: 'Better Luck\nNext Time', color: '#2c1060', text: '#a47dff' },
  { label: '10% Discount\nVoucher',   color: '#1a3a1a', text: '#80ffbb' },
  { label: 'Loyalty\nPoints +50',     color: '#1a1a3e', text: '#80d8ff' },
  { label: 'Free\nSticker Pack',      color: '#3a2a00', text: '#ffd700' },
  { label: 'Better Luck\nNext Time',  color: '#3a1020', text: '#ffaacc' },
  { label: 'Mystery\nBox',            color: '#1e2a3a', text: '#00d4ff' },
];

const SECTOR_COUNT = SECTORS.length;
const ARC = (2 * Math.PI) / SECTOR_COUNT;

let canvas, ctx, W, cx, cy, R;
let currentAngle = 0;
let spinning = false;
let spinResult = null;

function initWheel() {
  canvas = document.getElementById('spinWheel');
  if (!canvas) return;
  ctx = canvas.getContext('2d');
  W = canvas.width;
  cx = W / 2;
  cy = W / 2;
  R = W / 2 - 6;
  drawWheel(currentAngle);
}

function drawWheel(rotation) {
  ctx.clearRect(0, 0, W, W);

  // Outer ring glow
  ctx.save();
  ctx.shadowColor = 'rgba(108,53,222,0.6)';
  ctx.shadowBlur = 20;
  ctx.beginPath();
  ctx.arc(cx, cy, R + 4, 0, 2 * Math.PI);
  ctx.strokeStyle = 'rgba(160,125,255,0.5)';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();

  for (let i = 0; i < SECTOR_COUNT; i++) {
    const startAngle = rotation + i * ARC;
    const endAngle   = startAngle + ARC;
    const s = SECTORS[i];

    // Sector fill
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, R, startAngle, endAngle);
    ctx.closePath();
    ctx.fillStyle = s.color;
    ctx.fill();

    // Sector border
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Text
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(startAngle + ARC / 2);
    ctx.textAlign = 'right';
    ctx.fillStyle = s.text;
    ctx.font = 'bold 11px Poppins, sans-serif';

    const lines = s.label.split('\n');
    const lineH = 14;
    const offsetY = -(lines.length - 1) * lineH / 2;
    lines.forEach((line, li) => {
      ctx.fillText(line, R - 12, offsetY + li * lineH);
    });
    ctx.restore();
  }

  // Center circle
  const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 32);
  grad.addColorStop(0, '#a47dff');
  grad.addColorStop(1, '#6c35de');
  ctx.beginPath();
  ctx.arc(cx, cy, 30, 0, 2 * Math.PI);
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.2)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Center emoji
  ctx.font = '20px serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('🎰', cx, cy + 1);
  ctx.textBaseline = 'alphabetic';
}

function easeOut(t) {
  return 1 - Math.pow(1 - t, 3);
}

function spinTo(targetSector, totalRotation, onComplete) {
  const startAngle = currentAngle;
  const startTime = performance.now();
  const duration = 4000 + Math.random() * 1000;

  function animate(now) {
    const elapsed = now - startTime;
    const t = Math.min(elapsed / duration, 1);
    const eased = easeOut(t);
    currentAngle = startAngle + totalRotation * eased;
    drawWheel(currentAngle);

    if (t < 1) {
      requestAnimationFrame(animate);
    } else {
      spinning = false;
      if (onComplete) onComplete();
    }
  }

  requestAnimationFrame(animate);
}

function triggerSpin(resultSector, onComplete) {
  if (spinning) return;
  spinning = true;

  // At least 5 full rotations + land on the given sector
  const fullRotations = (5 + Math.floor(Math.random() * 4)) * 2 * Math.PI;
  const sectorAngle   = (SECTOR_COUNT - resultSector) * ARC - currentAngle % (2 * Math.PI);
  const totalSpin = fullRotations + ((sectorAngle % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);

  spinTo(resultSector, totalSpin, onComplete);
}

// ── Spin Button Handler ───────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  initWheel();

  const spinBtn   = document.getElementById('spinBtn');
  const resultBox = document.getElementById('spinResult');
  const prizeText = document.getElementById('prizeText');
  const msgText   = document.getElementById('msgText');
  const flagBox   = document.getElementById('flagBox');
  const flagText  = document.getElementById('flagText');

  if (!spinBtn) return;

  spinBtn.addEventListener('click', async () => {
    if (spinning) return;

    spinBtn.disabled = true;
    spinBtn.textContent = 'Spinning...';
    if (resultBox) { resultBox.classList.remove('show'); }

    try {
      const resp = await fetch('/user/spin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ spin: true }),
      });

      const data = await resp.json();

      triggerSpin(data.sector || 0, () => {
        // Show result
        if (prizeText) prizeText.textContent = data.prize || 'Result';
        if (msgText)   msgText.textContent   = data.message || '';

        if (data.flag && flagBox && flagText) {
          flagText.textContent = data.flag;
          flagBox.style.display = 'block';
          launchConfetti();
        } else if (flagBox) {
          flagBox.style.display = 'none';
        }

        if (resultBox) resultBox.classList.add('show');
        spinBtn.disabled = false;
        spinBtn.textContent = '🎰 Spin the Wheel!';
      });
    } catch (err) {
      spinning = false;
      spinBtn.disabled = false;
      spinBtn.textContent = '🎰 Spin the Wheel!';
    }
  });
});

// ── Confetti ──────────────────────────────────────────

function launchConfetti() {
  const colors = ['#ffd700','#a47dff','#ff4f8b','#00d4ff','#80ffbb','#fff'];
  for (let i = 0; i < 120; i++) {
    setTimeout(() => {
      const el = document.createElement('div');
      el.className = 'confetti-piece';
      el.style.left = Math.random() * 100 + 'vw';
      el.style.background = colors[Math.floor(Math.random() * colors.length)];
      el.style.width  = (6 + Math.random() * 8) + 'px';
      el.style.height = (6 + Math.random() * 8) + 'px';
      el.style.animationDuration = (2 + Math.random() * 2) + 's';
      el.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 4500);
    }, i * 25);
  }
}
