const express = require('express');
const router = express.Router();

// GET /api/v1/status — boring, nothing interesting
router.get('/v1/status', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.2.3',
    uptime: process.uptime().toFixed(0) + 's',
    timestamp: new Date().toISOString(),
  });
});

// GET /api/v1/health — INTENTIONALLY LEAKS admin credentials (debug leftover)
router.get('/v1/health', (req, res) => {
  res.json({
    status: 'healthy',
    version: '1.2.3',
    uptime: process.uptime().toFixed(0) + 's',
    services: {
      database: 'connected',
      cache: 'connected',
      storage: 'connected',
    },
    debug: {
      mode: 'enabled',
      note: 'TODO: disable debug mode before production release',
      seed_accounts: {
        admin: {
          username: 'admin',
          password: 'Adm1n@G1v3away!',
        },
      },
    },
    timestamp: new Date().toISOString(),
  });
});

// GET /api/v1/campaigns — public campaign list (no sensitive data)
router.get('/v1/campaigns', (req, res) => {
  res.json({
    campaigns: [
      { id: 1, name: 'Spring Mega Giveaway', status: 'active', prize_pool: '$5,000' },
      { id: 2, name: 'Refer & Earn', status: 'active', prize_pool: 'Loyalty Points' },
      { id: 3, name: 'Daily Lucky Spin',  status: 'active', prize_pool: 'Mixed' },
    ],
  });
});

module.exports = router;
