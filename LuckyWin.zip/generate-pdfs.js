const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

function generatePDFs() {
  generateFakePDFs();
  generateRealPDF();
}

// ── FAKE PDFs ─────────────────────────────────────────────────────────────────

function makeFakePDF(outputPath, title, role, description, content) {
  if (fs.existsSync(outputPath)) return;

  const doc = new PDFDocument({ margin: 60 });
  doc.pipe(fs.createWriteStream(outputPath));

  // Header
  doc.rect(0, 0, doc.page.width, 90).fill('#2c0a5e');
  doc.fontSize(22).fillColor('#ffffff').text('LuckyWin Giveaway Platform', 60, 28, { align: 'left' });
  doc.fontSize(10).fillColor('#c9a7ff').text('INTERNAL DOCUMENT — CONFIDENTIAL', 60, 58);

  doc.moveDown(3);
  doc.fontSize(18).fillColor('#2c0a5e').text(title, { align: 'center' });
  doc.moveDown(0.5);
  doc.fontSize(11).fillColor('#555').text(description, { align: 'center' });
  doc.moveDown(1.5);

  doc.moveTo(60, doc.y).lineTo(doc.page.width - 60, doc.y).stroke('#c9a7ff');
  doc.moveDown(1);

  doc.fontSize(12).fillColor('#333').text(content, { lineGap: 6 });

  doc.moveDown(2);
  doc.fontSize(11).fillColor('#888')
    .text(`Role required for elevated access: `, { continued: true })
    .fillColor('#c0392b').text(role);

  doc.moveDown(1);
  doc.fontSize(10).fillColor('#aaa')
    .text('Document generated: ' + new Date().toDateString());

  doc.end();
  console.log(`[PDF] Created: ${path.basename(outputPath)}`);
}

function generateFakePDFs() {
  makeFakePDF(
    path.join(__dirname, 'uploads', 'prize_catalogue_2024.pdf'),
    'LuckyWin Prize Catalogue — Q4 2024',
    'admin_override',
    'Internal prize inventory and distribution guide for platform administrators.',
    `This document outlines all prizes available in the LuckyWin Giveaway platform for Q4 2024.

Prize Tiers:
  • Tier 1 (Common): Discount vouchers, loyalty points, sticker packs
  • Tier 2 (Uncommon): Gift cards, mystery boxes, VIP event passes
  • Tier 3 (Rare): Electronics, holiday packages, cash prizes

Prize Distribution API:
  To manually assign prizes through the internal dashboard, administrators must
  authenticate with the platform API using the admin_override role.

  POST /api/v1/admin/prize-assign
  Headers: { "X-Internal-Role": "admin_override" }
  Body: { "userId": "<id>", "prizeId": "<prize_id>" }

NOTE: This endpoint is restricted to internal staff only. Unauthorized access
will be logged and reported to the security team.

All prize stock is updated weekly. Contact the warehouse team for urgent requests.
Approved by: Platform Operations Team
Revision: 4.1`
  );

  makeFakePDF(
    path.join(__dirname, 'uploads', 'terms_and_conditions.pdf'),
    'Giveaway Terms & Conditions — Legal Reference',
    'legal_admin',
    'Official terms, eligibility rules, and compliance requirements.',
    `LUCKYWIN GIVEAWAY PLATFORM — TERMS AND CONDITIONS

1. ELIGIBILITY
   Participants must be 18 years of age or older. Employees and their immediate
   family members of LuckyWin Corp are not eligible to participate.

2. HOW TO ENTER
   No purchase necessary. Participants may enter via the official platform at
   luckywin.example.com. One spin per registered account per day.

3. PRIZE FULFILLMENT
   Winners will be contacted via registered email within 7 business days.
   Unclaimed prizes expire after 30 days.

4. LEGAL TEAM ACCESS
   The compliance review dashboard is accessible only to staff members holding
   the legal_admin role in the platform's internal RBAC system.

   Access endpoint: /internal/compliance/review
   Role: legal_admin

5. DISPUTE RESOLUTION
   All disputes shall be settled under the jurisdiction of the platform's
   registered country of operation.

Approved by: Legal & Compliance Department
Last reviewed: January 2025`
  );

  makeFakePDF(
    path.join(__dirname, 'uploads', 'winner_verification_guide.pdf'),
    'Winner Verification & Audit Guide',
    'verifier',
    'Step-by-step guide for the prize verification team.',
    `WINNER VERIFICATION PROCESS — STAFF GUIDE

This guide is intended for the Prize Verification Team only.

STEP 1: Receive winner notification from automated system
STEP 2: Log into verification portal using your verifier role credentials
STEP 3: Cross-reference winner ID against the eligibility database
STEP 4: Confirm prize tier and stock availability
STEP 5: Issue fulfillment ticket to the warehouse team

VERIFICATION PORTAL ACCESS:
  URL: /internal/verify
  Required role: verifier
  Authentication: SSO via company identity provider

IMPORTANT: If a winner cannot be verified within 48 hours, escalate to the
Prize Operations Manager immediately.

AUDIT LOG:
  All verification actions are logged automatically.
  Logs are retained for 24 months for compliance purposes.

Approved by: Prize Operations Department
Version: 2.3 — March 2025`
  );

  makeFakePDF(
    path.join(__dirname, 'uploads', 'partner_integration_manual.pdf'),
    'Partner API Integration Manual',
    'partner_api',
    'Technical guide for third-party partners integrating with LuckyWin.',
    `LUCKYWIN PARTNER INTEGRATION MANUAL — CONFIDENTIAL

This document is intended for authorized technology partners only.

OVERVIEW:
  Partners can integrate with the LuckyWin platform to co-host giveaway
  campaigns, sync prize pools, and retrieve winner data via our REST API.

AUTHENTICATION:
  Partners must use OAuth2 client credentials flow.
  Grant type: client_credentials
  Scope: partner_api

  Example token request:
  POST /oauth/token
  { "grant_type": "client_credentials", "scope": "partner_api" }

AVAILABLE ENDPOINTS:
  GET  /api/partner/v1/campaigns     - List active campaigns
  POST /api/partner/v1/spin-trigger  - Trigger a spin on behalf of user
  GET  /api/partner/v1/winners       - Retrieve winner list

RATE LIMITS:
  100 requests per minute per partner client ID.
  Exceeding this limit will result in a 429 Too Many Requests response.

For technical support, contact: partners@luckywin.example.com

Revision: 1.8 — February 2025
Approved by: Partner Engineering Team`
  );
}

// ── REAL PDF ──────────────────────────────────────────────────────────────────

function generateRealPDF() {
  const outputPath = path.join(__dirname, 'internal', 'docs', 'Q1_2026_budget_review.pdf');
  if (fs.existsSync(outputPath)) return;

  const doc = new PDFDocument({ margin: 60 });
  doc.pipe(fs.createWriteStream(outputPath));

  // Header bar
  doc.rect(0, 0, doc.page.width, 90).fill('#1a3a1a');
  doc.fontSize(20).fillColor('#ffffff').text('LuckyWin Corp — INTERNAL USE ONLY', 60, 25);
  doc.fontSize(10).fillColor('#a0ffa0').text('Q1 2026 Budget Review & System Notes  |  Finance & Engineering Joint Report', 60, 55);

  doc.moveDown(3.5);

  // Title
  doc.fontSize(17).fillColor('#1a3a1a').text('Q1 2026 Budget Review', { align: 'center' });
  doc.moveDown(0.3);
  doc.fontSize(10).fillColor('#777').text('Prepared by: Finance Dept. & Platform Engineering  |  DRAFT — Not for distribution', { align: 'center' });

  doc.moveDown(1.2);
  doc.moveTo(60, doc.y).lineTo(doc.page.width - 60, doc.y).stroke('#aaa');
  doc.moveDown(1);

  // Section 1
  doc.fontSize(13).fillColor('#1a3a1a').text('1. Executive Summary');
  doc.moveDown(0.4);
  doc.fontSize(11).fillColor('#333').text(
    `Q1 2026 saw a 34% increase in platform participation across all active giveaway campaigns. ` +
    `Prize redemption rates improved by 18% compared to Q4 2025 following UX improvements to the ` +
    `Lucky Spin module. Server costs increased by 12% due to infrastructure scaling for the ` +
    `Valentine's Day campaign surge. Overall platform revenue is on track.`,
    { lineGap: 5 }
  );

  doc.moveDown(1);

  // Section 2
  doc.fontSize(13).fillColor('#1a3a1a').text('2. Campaign Spend Breakdown');
  doc.moveDown(0.4);
  doc.fontSize(11).fillColor('#333').text(
    `  • Social media advertising:   $18,400\n` +
    `  • Prize procurement (Tier 1): $6,200\n` +
    `  • Prize procurement (Tier 2): $14,750\n` +
    `  • Infrastructure & hosting:   $3,100\n` +
    `  • Partner integrations:       $2,050\n` +
    `  • Miscellaneous:              $990\n` +
    `  ──────────────────────────────────\n` +
    `  Total Q1 spend:               $45,490`,
    { lineGap: 4 }
  );

  doc.moveDown(1);

  // Section 3
  doc.fontSize(13).fillColor('#1a3a1a').text('3. Platform Engineering Notes');
  doc.moveDown(0.4);
  doc.fontSize(11).fillColor('#333').text(
    `The following notes were appended by the Platform Engineering team during the quarterly ` +
    `review. These are operational items flagged for action in Q2.`,
    { lineGap: 5 }
  );

  doc.moveDown(0.7);
  doc.fontSize(11).fillColor('#333').text('3.1  Lucky Spin Module — Access Control Update', { underline: true });
  doc.moveDown(0.3);
  doc.fontSize(11).fillColor('#333').text(
    `The spin endpoint was refactored in February to support role-based prize pools. ` +
    `Sponsors participating in co-branded campaigns can now access elevated prize tiers ` +
    `by embedding their authorization role in the spin request payload.`,
    { lineGap: 5 }
  );

  doc.moveDown(0.5);

  // The KEY info — looks like a developer's note, slightly buried
  doc.rect(60, doc.y, doc.page.width - 120, 105).fill('#f0fff0').stroke('#4caf50');
  const boxY = doc.y + 10;
  doc.fontSize(10).fillColor('#1a3a1a').text(
    `[DEV NOTE — Pending removal before public release]\n\n` +
    `For verified sponsor campaign access, include the following field in the\n` +
    `POST /user/spin request body alongside the standard spin payload:\n\n` +
    `    "role": "verified_sponsor"\n\n` +
    `This unlocks the Tier-3 Grand Prize pool for the requesting session.\n` +
    `Remove this note and restrict the parameter server-side before v2.1 launch.`,
    60 + 10, boxY, { lineGap: 4, width: doc.page.width - 140 }
  );

  doc.moveDown(8);

  // Section 4
  doc.fontSize(13).fillColor('#1a3a1a').text('4. Q2 2026 Projections');
  doc.moveDown(0.4);
  doc.fontSize(11).fillColor('#333').text(
    `Q2 campaigns are projected to reach 2x participation based on current registration ` +
    `growth trends. Budget allocation for Q2 is set at $62,000 pending board approval. ` +
    `Server infrastructure upgrades are scheduled for April 28 — expected 4-hour downtime.`,
    { lineGap: 5 }
  );

  doc.moveDown(1);

  // Footer
  doc.fontSize(9).fillColor('#aaa')
    .text('CONFIDENTIAL — LuckyWin Corp Internal Document — Q1 2026', { align: 'center' })
    .text('Do not distribute outside of Finance & Engineering departments.', { align: 'center' });

  doc.end();
  console.log('[PDF] Created: Q1_2026_budget_review.pdf (internal)');
}

module.exports = generatePDFs;
