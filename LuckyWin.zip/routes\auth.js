const express = require('express');
const router = express.Router();

// In-memory users — intentionally no SQL injection surface
// Credentials for admin are discoverable via /api/v1/health
const USERS = {
  admin: {
    password: 'Adm1n@G1v3away!',
    role: 'admin',
    name: 'Platform Admin',
  },
  player: {
    password: 'player123',
    role: 'user',
    name: 'Lucky Player',
  },
};

// Rate limit map — prevent brute force (per IP, per username)
const loginAttempts = {};

function getRateLimitKey(req, username) {
  const ip = req.ip || req.connection.remoteAddress;
  return `${ip}:${username}`;
}

// POST /auth/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.render('landing', { error: 'Please enter your credentials.' });
  }

  const key = getRateLimitKey(req, username);
  const now = Date.now();

  // Initialize or reset window
  if (!loginAttempts[key]) loginAttempts[key] = { count: 0, windowStart: now };
  const attempt = loginAttempts[key];

  // Reset window every 10 minutes
  if (now - attempt.windowStart > 10 * 60 * 1000) {
    attempt.count = 0;
    attempt.windowStart = now;
  }

  // Block after 5 failed attempts — prevent brute force
  if (attempt.count >= 5) {
    return res.render('landing', {
      error: 'Too many failed attempts. Please try again later.',
    });
  }

  const user = USERS[username];

  // Constant-time check (no username enumeration — same error for wrong user/pass)
  const validUser = user && user.password === password;

  if (!validUser) {
    attempt.count++;
    return res.render('landing', { error: 'Invalid credentials. Please try again.' });
  }

  // Reset attempts on success
  attempt.count = 0;

  req.session.user = {
    username,
    role: user.role,
    name: user.name,
  };

  if (user.role === 'admin') return res.redirect('/admin/dashboard');
  return res.redirect('/user/dashboard');
});

// POST /auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

module.exports = router;
