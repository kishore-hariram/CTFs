const express = require('express');
const router = express.Router();

// Middleware — logged-in users only
function requireUser(req, res, next) {
  if (req.session && req.session.user) return next();
  res.redirect('/');
}

// Prize history (fake, rabbit hole)
const PRIZE_HISTORY = [
  { date: '2026-04-18', prize: 'Better Luck Next Time', spin: '#00841' },
  { date: '2026-04-15', prize: '10% Discount Voucher', spin: '#00798', code: 'DISC-4471-XY' },
  { date: '2026-04-10', prize: 'Better Luck Next Time', spin: '#00712' },
  { date: '2026-03-29', prize: 'Loyalty Points +50', spin: '#00634' },
  { date: '2026-03-20', prize: 'Free Sticker Pack', spin: '#00571', status: 'Shipped' },
];

// Referral stats (fake, rabbit hole)
const REFERRAL_DATA = {
  code: 'LUCKY-PL4YER-9921',
  totalReferrals: 3,
  pendingRewards: 1,
  referrals: [
    { username: 'user_***12', joined: '2026-04-01', reward: 'Pending' },
    { username: 'user_***47', joined: '2026-03-18', reward: 'Claimed' },
    { username: 'user_***80', joined: '2026-03-05', reward: 'Claimed' },
  ],
};

// Spin outcomes (normal — no flag)
const NORMAL_OUTCOMES = [
  'Better Luck Next Time',
  '10% Discount Voucher',
  'Loyalty Points +50',
  'Free Sticker Pack',
  'Better Luck Next Time',
  'Mystery Box',
];

// GET /user/dashboard
router.get('/dashboard', requireUser, (req, res) => {
  res.render('user/dashboard', { user: req.session.user });
});

// GET /user/prizes
router.get('/prizes', requireUser, (req, res) => {
  res.render('user/prizes', { user: req.session.user, prizes: PRIZE_HISTORY });
});

// GET /user/referral
router.get('/referral', requireUser, (req, res) => {
  res.render('user/referral', { user: req.session.user, referral: REFERRAL_DATA });
});

// GET /user/profile
router.get('/profile', requireUser, (req, res) => {
  res.render('user/profile', {
    user: req.session.user,
    success: req.query.saved === '1' ? 'Profile updated successfully.' : null,
  });
});

// POST /user/profile — dummy update (no real vulnerability here)
router.post('/profile', requireUser, (req, res) => {
  // Only update display name — no privilege escalation possible here
  const { displayName } = req.body;
  if (displayName && displayName.trim()) {
    req.session.user.name = displayName.trim().substring(0, 40);
  }
  res.redirect('/user/profile?saved=1');
});

// GET /user/spin
router.get('/spin', requireUser, (req, res) => {
  res.render('user/spin', { user: req.session.user });
});

// POST /user/spin  — VULNERABLE TO MASS ASSIGNMENT
router.post('/spin', requireUser, (req, res) => {
  const body = req.body;

  // ⚠️  INTENTIONALLY VULNERABLE — role is blindly merged from request body
  // Normal request: { "spin": true }
  // Exploit:        { "spin": true, "role": "verified_sponsor" }
  const spinData = Object.assign({}, body);

  if (!spinData.spin) {
    return res.json({ success: false, message: 'Invalid spin request.' });
  }

  // Check role from the (mass-assigned) data
  if (spinData.role === 'verified_sponsor') {
    return res.json({
      success: true,
      prize: '🏆 GRAND PRIZE UNLOCKED',
      flag: 'FLAG{you_spun_the_wheel_of_fortune}',
      message: 'Congratulations! You have been verified as a sponsor and unlocked the Grand Prize!',
      sector: 6,
    });
  }

  // Normal outcome — random pick
  const outcome = NORMAL_OUTCOMES[Math.floor(Math.random() * NORMAL_OUTCOMES.length)];
  const sector = Math.floor(Math.random() * 6);

  return res.json({
    success: true,
    prize: outcome,
    message: outcome === 'Better Luck Next Time'
      ? 'Keep spinning — your lucky day is coming!'
      : `You won: ${outcome}!`,
    sector,
  });
});

module.exports = router;
