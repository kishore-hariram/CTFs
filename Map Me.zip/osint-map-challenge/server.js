const express = require('express');
const path = require('path');
const rateLimit = require('express-rate-limit');
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Rate Limiter to prevent API brute-forcing
const verifyLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: { error: 'Too many guesses, please try again later.' }
});

const claimLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 20, // Strict limit for claiming the final flag
    message: { error: 'Too many attempts to claim flag, please try again later.' }
});

const RADIUS_METERS = 100;
const FINAL_FLAG = "CTF{0s1nt_g30gu3ss_m4st3r}";

// The 6 challenges. Target coordinates and tokens are kept securely on the backend.
// Players MUST supply the correct coordinates to get the token.
const challenges = [
    {
        id: 1,
        category: "Ireland",
        imageUrl: "/3.png",
        targetLat: 52.5145673,
        targetLng: -7.8844858,
        token: "tok_9a2f1b4c7d0e8f"
    },
    {
        id: 2,
        category: "Ireland",
        imageUrl: "/2.png",
        targetLat: 53.34573409101009,
        targetLng: -6.265169384258358,
        token: "tok_5c8e2a1d9b3f4g"
    },
    {
        id: 3,
        category: "Ireland",
        is360: false, 
        imageUrl: "/1.png",
        targetLat: 52.93938971276318,
        targetLng: -9.293327636388074,
        token: "tok_1f4b7e0c9a2d8h"
    },
    {
        id: 4,
        category: "International",
        imageUrl: "/4.png",
        targetLat: 50.05889296285905,
        targetLng: 19.9248255341098,
        token: "tok_8d2e5a1c9f4b7i"
    },
    {
        id: 5,
        category: "International",
        imageUrl: "/5.png",
        targetLat: -37.81919813625088,
        targetLng: 144.9819052653713,
        token: "tok_3b6c9f2e8a1d4j"
    },
    {
        id: 6,
        category: "International",
        imageUrl: "/6.png",
        targetLat: 40.70293298368302,
        targetLng: -73.9950336457611,
        token: "tok_7a1d4c9e2b5f8k"
    }
];

// Haversine formula to calculate distance in meters
function getDistanceFromLatLonInM(lat1, lon1, lat2, lon2) {
  var R = 6371e3; 
  var dLat = deg2rad(lat2-lat1);
  var dLon = deg2rad(lon2-lon1); 
  var a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2); 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c; 
  return d;
}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}

// Endpoint to fetch challenges safely
app.get('/api/challenges', (req, res) => {
    const safeChallenges = challenges.map(c => ({
        id: c.id,
        category: c.category,
        imageUrl: c.imageUrl,
        is360: c.is360
    }));
    res.json(safeChallenges);
});

// Endpoint to verify a single location and return a token
app.post('/api/verify', verifyLimiter, (req, res) => {
  const { id, lat, lng } = req.body;

  if (id == null || lat == null || lng == null) {
      return res.status(400).json({ error: 'Missing challenge ID or coordinates' });
  }

  const challenge = challenges.find(c => c.id === parseInt(id));
  if (!challenge) {
      return res.status(404).json({ error: 'Challenge not found' });
  }

  const distance = getDistanceFromLatLonInM(challenge.targetLat, challenge.targetLng, lat, lng);
  
  if (distance <= RADIUS_METERS) {
      // Return the token instead of the final flag
      res.json({ success: true, message: 'Location solved! Token acquired.', token: challenge.token, distance: distance.toFixed(2) });
  } else {
      res.json({ success: false, message: 'Incorrect location.', distance: distance.toFixed(2) });
  }
});

// Endpoint to claim the final flag by providing all 6 valid tokens
app.post('/api/claim-flag', claimLimiter, (req, res) => {
    const { tokens } = req.body;

    if (!Array.isArray(tokens)) {
        return res.status(400).json({ error: 'Tokens array is required.' });
    }

    // Check if the provided tokens array contains exactly all 6 required tokens
    const validTokens = challenges.map(c => c.token);
    
    let isValid = true;
    for (const validToken of validTokens) {
        if (!tokens.includes(validToken)) {
            isValid = false;
            break;
        }
    }

    if (isValid && tokens.length === validTokens.length) {
        res.json({ success: true, message: 'All locations verified!', flag: FINAL_FLAG });
    } else {
        res.status(401).json({ error: 'Invalid or missing tokens. You must solve all locations first.' });
    }
});

app.listen(port, () => {
  console.log(`OSINT Map Dashboard listening at http://localhost:${port}`);
});
