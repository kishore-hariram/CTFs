package com.seminar.xssdemo.service;

import com.seminar.xssdemo.model.SearchLog;
import com.seminar.xssdemo.repository.SearchLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SearchLogService {

    @Autowired
    private SearchLogRepository searchLogRepository;

    // Saves the raw query string directly — no sanitization performed
    public void saveSearch(String query, String ipAddress) {
        SearchLog log = new SearchLog(query, LocalDateTime.now(), ipAddress);
        searchLogRepository.save(log);
    }

    public List<SearchLog> getAllLogs() {
        return searchLogRepository.findAllByOrderBySearchedAtDesc();
    }

    public void clearAllLogs() {
        searchLogRepository.deleteAll();
    }
}
