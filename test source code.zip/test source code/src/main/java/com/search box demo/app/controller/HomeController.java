package com.seminar.xssdemo.controller;

import com.seminar.xssdemo.service.SearchLogService;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @Autowired
    private SearchLogService searchLogService;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("query", null);
        model.addAttribute("searched", false);
        return "index";
    }

    @GetMapping("/search")
    public String search(@RequestParam(value = "q", defaultValue = "") String query,
                         HttpServletRequest request,
                         Model model) {

        // Save the raw, unsanitized query to the database
        String ipAddress = request.getRemoteAddr();
        searchLogService.saveSearch(query, ipAddress);

        // Pass the raw query directly to the template — XSS vulnerability here
        model.addAttribute("query", query);
        model.addAttribute("searched", true);

        return "index";
    }
}
