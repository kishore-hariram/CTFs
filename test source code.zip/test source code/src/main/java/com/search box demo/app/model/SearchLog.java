package com.seminar.xssdemo.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "search_logs")
public class SearchLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "query", length = 1024)
    private String query;

    @Column(name = "searched_at")
    private LocalDateTime searchedAt;

    @Column(name = "ip_address")
    private String ipAddress;

    public SearchLog() {}

    public SearchLog(String query, LocalDateTime searchedAt, String ipAddress) {
        this.query = query;
        this.searchedAt = searchedAt;
        this.ipAddress = ipAddress;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public LocalDateTime getSearchedAt() {
        return searchedAt;
    }

    public void setSearchedAt(LocalDateTime searchedAt) {
        this.searchedAt = searchedAt;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
}
