package com.seminar.xssdemo.controller;

import com.seminar.xssdemo.service.SearchLogService;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DashboardController {

    @Autowired
    private SearchLogService searchLogService;

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        // Manual session check — no Spring Security, just a session attribute
        Boolean loggedIn = (Boolean) session.getAttribute("loggedIn");
        if (loggedIn == null || !loggedIn) {
            return "redirect:/login";
        }

        String username = (String) session.getAttribute("username");
        model.addAttribute("username", username);
        model.addAttribute("logs", searchLogService.getAllLogs());
        return "dashboard";
    }

    @PostMapping("/dashboard/clear")
    public String clearLogs(HttpSession session) {
        Boolean loggedIn = (Boolean) session.getAttribute("loggedIn");
        if (loggedIn == null || !loggedIn) {
            return "redirect:/login";
        }

        searchLogService.clearAllLogs();
        return "redirect:/dashboard";
    }
}
