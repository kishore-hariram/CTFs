const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const authRouter = require('./routes/auth');
const adminRouter = require('./routes/admin');
const userRouter = require('./routes/user');
const apiRouter = require('./routes/api');

const app = express();

// Ensure required directories exist
const dirs = [
  path.join(__dirname, 'uploads'),
  path.join(__dirname, 'internal', 'docs'),
];
dirs.forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// Generate PDFs on startup if missing
require('./generate-pdfs')();

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: 'l4cky-sp1n-s3cr3t-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false,
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 2 // 2 hours
  }
}));

// Routes
app.use('/auth', authRouter);
app.use('/admin', adminRouter);
app.use('/user', userRouter);
app.use('/api', apiRouter);

// Landing page
app.get('/', (req, res) => {
  if (req.session && req.session.user) {
    if (req.session.user.role === 'admin') return res.redirect('/admin/dashboard');
    return res.redirect('/user/dashboard');
  }
  res.render('landing');
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('404');
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`\n🎰 Lucky Spin Giveaway Platform running on http://localhost:${PORT}`);
  console.log(`   Press Ctrl+C to stop.\n`);
});
