const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const multer = require('multer');

// Multer setup — store uploaded PDFs in /uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'uploads')),
  filename: (req, file, cb) => cb(null, Date.now() + '_' + file.originalname),
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') cb(null, true);
    else cb(new Error('Only PDF files are allowed'));
  },
  limits: { fileSize: 5 * 1024 * 1024 },
});

// Middleware — admin only
function requireAdmin(req, res, next) {
  if (req.session && req.session.user && req.session.user.role === 'admin') {
    return next();
  }
  res.redirect('/');
}

function getUploadedFiles() {
  const uploadDir = path.join(__dirname, '..', 'uploads');
  try {
    return fs.readdirSync(uploadDir).filter(f => f.endsWith('.pdf'));
  } catch {
    return [];
  }
}

// Fake stats data
const FAKE_STATS = {
  totalSpins: 18472,
  totalWinners: 3214,
  activeCampaigns: 3,
  totalUsers: 9841,
  monthlySpins: [920, 1340, 1780, 2100, 2450, 2980, 3120, 2860, 2400, 3200, 3580, 4100],
  recentWinners: [
    { name: 'user_***47', prize: '10% Discount Voucher', date: '2026-04-19' },
    { name: 'user_***12', prize: 'Loyalty Points +50', date: '2026-04-19' },
    { name: 'user_***88', prize: 'Free Sticker Pack', date: '2026-04-18' },
    { name: 'user_***33', prize: 'Mystery Box', date: '2026-04-18' },
    { name: 'user_***56', prize: 'VIP Entry', date: '2026-04-17' },
  ],
};

const FAKE_USERS = [
  { id: 1, username: 'player', name: 'Lucky Player', email: 'player@example.com', spins: 12, joined: '2026-03-01', status: 'Active' },
  { id: 2, username: 'user_9921', name: 'Alex M.', email: 'alexm@example.com', spins: 7, joined: '2026-03-14', status: 'Active' },
  { id: 3, username: 'user_4471', name: 'Jordan K.', email: 'jk@example.com', spins: 23, joined: '2026-02-28', status: 'Active' },
  { id: 4, username: 'user_8803', name: 'Sam T.', email: 'samt@example.com', spins: 3, joined: '2026-04-01', status: 'Suspended' },
  { id: 5, username: 'user_2259', name: 'Riley V.', email: 'riley@example.com', spins: 18, joined: '2026-03-22', status: 'Active' },
  { id: 6, username: 'user_6612', name: 'Morgan B.', email: 'morganb@example.com', spins: 9, joined: '2026-04-10', status: 'Active' },
  { id: 7, username: 'user_1104', name: 'Casey R.', email: 'casey@example.com', spins: 0, joined: '2026-04-15', status: 'Inactive' },
];

// ── ROUTES ───────────────────────────────────────────────────────────────────

// GET /admin/dashboard
router.get('/dashboard', requireAdmin, (req, res) => {
  res.render('admin/dashboard', { user: req.session.user, stats: FAKE_STATS });
});

// GET /admin/users
router.get('/users', requireAdmin, (req, res) => {
  res.render('admin/users', { user: req.session.user, users: FAKE_USERS });
});

// GET /admin/stats
router.get('/stats', requireAdmin, (req, res) => {
  res.render('admin/stats', { user: req.session.user, stats: FAKE_STATS });
});

// GET /admin/pdf-viewer — renders the vault page (no LFI here)
router.get('/pdf-viewer', requireAdmin, (req, res) => {
  const file = req.query.file;
  const files = getUploadedFiles();

  if (!file) {
    return res.render('admin/pdf-viewer', {
      user: req.session.user,
      files,
      pdfUrl: null,
      error: null,
    });
  }

  // Pass a pdfUrl that the iframe will load — actual file serving is in /admin/pdf-serve
  const pdfUrl = '/admin/pdf-serve?file=' + encodeURIComponent(file);
  return res.render('admin/pdf-viewer', {
    user: req.session.user,
    files,
    pdfUrl,
    error: null,
  });
});

// GET /admin/pdf-serve — VULNERABLE TO LFI (serves raw PDF bytes)
router.get('/pdf-serve', requireAdmin, (req, res) => {
  const file = req.query.file;
  if (!file) return res.status(400).send('No file specified.');

  // ⚠️  INTENTIONALLY VULNERABLE — No path traversal protection
  // path.join normalises ".." so ?file=../internal/docs/file.pdf traverses out of /uploads
  const filePath = path.join(__dirname, '..', 'uploads', file);

  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File not found.');
  }

  const stat = fs.statSync(filePath);

  // ── Directory listing (LFI traversal aid) ──────────────────────────────────
  if (stat.isDirectory()) {
    const entries = fs.readdirSync(filePath).map(name => {
      const entryPath = path.join(filePath, name);
      const entryStat = fs.statSync(entryPath);
      const isDir = entryStat.isDirectory();
      const href  = '/admin/pdf-serve?file=' + encodeURIComponent(
        file.replace(/\/+$/, '') + '/' + name + (isDir ? '/' : '')
      );
      return `<tr>
        <td style="padding:8px 12px;font-family:monospace;">
          ${isDir ? '📁' : '📄'} <a href="${href}" style="color:#a47dff;">${name}${isDir ? '/' : ''}</a>
        </td>
        <td style="padding:8px 12px;color:#888;font-size:0.85rem;">${isDir ? 'Directory' : entryStat.size + ' bytes'}</td>
      </tr>`;
    }).join('');

    const parentFile = file.replace(/\/+$/, '').split('/').slice(0, -1).join('/');
    const parentHref = parentFile
      ? '/admin/pdf-serve?file=' + encodeURIComponent(parentFile + '/')
      : '/admin/pdf-serve?file=';

    return res.send(`<!DOCTYPE html>
<html><head>
  <meta charset="UTF-8"/>
  <title>Index of ${path.basename(filePath)}</title>
  <style>
    body{background:#0a0a1a;color:#e0e0ff;font-family:monospace;padding:32px;}
    h2{color:#a47dff;margin-bottom:4px;}p{color:#666;font-size:0.85rem;margin-bottom:20px;}
    table{border-collapse:collapse;width:100%;max-width:700px;}
    tr{border-bottom:1px solid rgba(255,255,255,0.06);}
    tr:hover{background:rgba(255,255,255,0.04);}
    a{text-decoration:none;}a:hover{text-decoration:underline;}
  </style>
</head><body>
  <h2>📂 Index of /${path.basename(filePath)}/</h2>
  <p>Path: uploads/${file}</p>
  <table>
    <tr><td style="padding:8px 12px;">📁 <a href="${parentHref}" style="color:#a47dff;">..</a></td><td></td></tr>
    ${entries}
  </table>
</body></html>`);
  }

  // ── Serve PDF ──────────────────────────────────────────────────────────────
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="${path.basename(file)}"`);
  res.sendFile(filePath);
});

// POST /admin/upload-pdf
router.post('/upload-pdf', requireAdmin, upload.single('pdf'), (req, res) => {
  if (!req.file) {
    return res.redirect('/admin/pdf-viewer?error=no_file');
  }
  res.redirect('/admin/pdf-viewer?file=' + req.file.filename + '&uploaded=1');
});

module.exports = router;
